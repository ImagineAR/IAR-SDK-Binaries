//
//  Vuforia.h
//  Vuforia
//
//  Created by Rogerio on 2021-11-16.
//

#import <Foundation/Foundation.h>

//! Project version number for Vuforia.
FOUNDATION_EXPORT double VuforiaVersionNumber;

//! Project version string for Vuforia.
FOUNDATION_EXPORT const unsigned char VuforiaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Vuforia/PublicHeader.h>


