//
//  VuforiaObjects.h
//  VuforiaSampleSwift
//
//  Created by Yoshihiro Kato on 2016/07/02.
//  Copyright © 2016年 Yoshihiro Kato. All rights reserved.
//

#import <Foundation/Foundation.h>

#if !(TARGET_OS_SIMULATOR)
typedef NS_ENUM(NSUInteger, VuforiaTrackableResultStatus) {
    VuforiaTrackableResultStatus_Unknown,            ///< The state of the TrackableResult is unknown
    VuforiaTrackableResultStatus_No_Pose,          ///<
    VuforiaTrackableResultStatus_Limited,          ///<
    VuforiaTrackableResultStatus_Detected,           ///< The TrackableResult was detected
    VuforiaTrackableResultStatus_Tracked,            ///< The TrackableResult was tracked
    VuforiaTrackableResultStatus_Extended_tracked    ///< The Trackable Result was extended tracked
};

@interface VuforiaFrame : NSObject
@end

@interface VuforiaTrackable : NSObject

@property (nonatomic, readonly)NSInteger identifier;
@property (nonatomic, readonly)NSString* name;

@end

@interface VuforiaTrackableResult : NSObject

@property (nonatomic, readonly)NSTimeInterval timeStamp;
@property (nonatomic, readonly)VuforiaTrackableResultStatus status;
@property (nonatomic, readonly)VuforiaTrackable* trackable;

@end

@interface VuforiaState : NSObject

@property (nonatomic, readonly)VuforiaFrame* frame;
@property (nonatomic, readonly)int numberOfTrackables;
@property (nonatomic, readonly)int numberOfTrackableResults;

@end

@protocol VuforiaApplicationControl

@required
// this method is called to notify the application that the initialization (initAR) is complete
// usually the application then starts the AR through a call to startAR
-(void)onInitARDone: (NSError *)error;

// the application must initialize its tracker(s)
-(bool)doInitTrackers;

// the application must initialize the data associated to its tracker(s)
-(bool)doLoadTrackersData;

// the application must starts its tracker(s)
-(bool)doStartTrackers;

// the application must stop its tracker(s)
-(bool)doStopTrackers;

// the application must unload the data associated its tracker(s)
-(bool)doUnloadTrackersData;

// the application must deinititalize its tracker(s)
-(bool)doDeinitTrackers;

@optional
// optional method to handle the Vuforia Engine callback - can be used to swap dataset for instance
-(void)onVuforiaUpdate: (VuforiaState*)state;

@end
#endif
