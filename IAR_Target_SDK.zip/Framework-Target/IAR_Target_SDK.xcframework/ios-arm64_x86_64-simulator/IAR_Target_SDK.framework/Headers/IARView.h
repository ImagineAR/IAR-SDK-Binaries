//
//  BaseArView.h
//  IAR Demo
//
//  Created by Wes Goodhoofd on 2020-01-29.
//  Copyright © 2020 Imagination Park Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <SceneKit/SceneKit.h>

NS_ASSUME_NONNULL_BEGIN

@class IARManager;

typedef NS_ENUM(NSInteger, RenderMode) {
    RenderModeNone,
    RenderModeWaiting,
    RenderMode2d,
    RenderMode3d,
    RenderModeVideo
};

@interface IARView : UIView <SCNSceneRendererDelegate>

@property (nonatomic, retain) IARManager * manager;

@end

NS_ASSUME_NONNULL_END
