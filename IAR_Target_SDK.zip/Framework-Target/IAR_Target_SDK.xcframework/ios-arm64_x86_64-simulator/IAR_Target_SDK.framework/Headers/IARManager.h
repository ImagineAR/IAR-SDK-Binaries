/*===============================================================================
Copyright (c) 2019 PTC Inc. All Rights Reserved.
 
Confidential and Proprietary - Protected under copyright and other laws.
Vuforia is a trademark of PTC Inc., registered in the United States and other
countries.
===============================================================================*/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <SceneKit/SceneKit.h>

#import "VuforiaObjects.h"
#import "IARView.h"

//#import <IAR_Core_SDK/Marker.h>
//#import <IAR_Core_SDK/Reward.h>

@class Marker;
@class Reward;

@class IARManager;

// the AR Application now only receives high level messages
// all processing, loading and displaying is handled internally by the manager
@protocol IARManagerDelegate

@required

/// Called when the IAR library and Vuforia complete initialization. Can indicate an error with the IAR setup or Vuforia
/// @param manager IARManager object
/// @param error optional error message relating to overall initialization
-(void)manager: (IARManager* _Nonnull)manager onInitARDone: (NSError * _Nullable)error;

/// Called when a generic error takes place
/// @param manager IARManager object
/// @param error object containing error information
-(void)manager: (IARManager* _Nonnull)manager onError: (NSError* _Nonnull)error;

@optional
/// Called immediately when the marker has a reward to display
/// @param manager IARmanager object
/// @param marker Marker object
-(void)manager: (IARManager* _Nonnull)manager markerHasReward: (Marker * _Nonnull)marker;
/// Called when the rewards objects and associated files have been downloaded
/// @param manager IARManager object
/// @param rewards Reward object array
-(void)manager: (IARManager* _Nonnull)manager didReceiveRewards: (NSArray<Reward *> * _Nonnull)rewards;
/// Called to check if the augmentation for the selected target should actually render
/// @param manager IARManager object
/// @param targetId target ID string provided by Vuforia
-(bool)manager: (IARManager* _Nonnull)manager shouldRenderAugmentation: (NSString* _Nonnull)targetId;
/// Called when the API returns the marker object after Vuforia matches an image target
/// @param manager IARManager object
/// @param marker Marker object
-(void)manager: (IARManager* _Nonnull)manager didScanTarget: (Marker * _Nonnull)marker;
/// Called when the visual image target tracker begins or stops scanning
/// @param manager IARManager object
/// @param isTracking boolean of whether the tracker is actively tracking
-(void)manager: (IARManager* _Nonnull)manager onTrackingChanged: (BOOL)isTracking;
/// Callback passed by Alamofire progress block for indicating that an asset is being downloaded
/// @param manager IARManager object
/// @param progress percentage 0-1 of how much of the download is complete
-(void)manager: (IARManager* _Nonnull)manager downloadProgress: (CGFloat)progress;

- (UIImage* _Nullable) managerProvideLoadingImage: (IARManager* _Nonnull)manager;


/// THIS METHOD IS DEPRECATED. Use manager:didReceiveRewards instead
/// @deprecated Use 'didReceiveRewards' instead. (To retrieve an array of rewards instead of one reward)
-(void)manager: (IARManager* _Nonnull)manager didReceiveReward: (Reward * _Nonnull)reward
    __attribute__((deprecated("The SDK now provides an array of rewards", "manager:didReceiveRewards")));

@end

#if !(TARGET_OS_SIMULATOR)
@interface IARManager : NSObject <VuforiaApplicationControl>
#else
@interface IARManager : NSObject
#endif

-(instancetype _Nonnull)initWithDelegate: (NSObject<IARManagerDelegate>* _Nonnull)aDelegate usingView: (IARView* _Nonnull)view;

-(void)stopAr;
-(void)pauseAr;
-(void)resumeAr;
-(void)handleTarget: (NSString* _Nonnull)targetId
           callback: (void (^_Nonnull)(Marker * _Nullable marker))callback;

-(void)pauseVideo;
-(void)resumeVideo;

@end
