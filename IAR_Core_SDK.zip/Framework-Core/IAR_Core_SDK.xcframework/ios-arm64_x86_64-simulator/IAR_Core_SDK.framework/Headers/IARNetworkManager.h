//
//  IARNetworkManager.h
//  IAR
//
//  Created by Wes Goodhoofd on 2020-02-27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class Marker;
@class Reward;
@class Hunt;

typedef void (^CreateExternalUserIdCallback)(NSString* _Nullable externalUserId, NSError* _Nullable error);
typedef void (^MigrateDataCallback)(NSError* _Nullable error);
typedef void (^MarkerAndErrorCallback)(Marker* _Nullable marker, NSError* _Nullable error);
typedef void (^RewardAndErrorCallback)(Reward* _Nullable reward, NSError* _Nullable error);
typedef void (^MarkerListAndErrorCallback)(NSArray<Marker *>* _Nullable markers, NSError* _Nullable error);
typedef void (^HuntsListAndErrorCallback)(NSArray<Hunt*>* _Nullable hunt, NSError* _Nullable error);
typedef void (^HuntAndErrorCallback)(Hunt* _Nullable hunt, NSError* _Nullable error);
typedef void (^RewardListCallback)(NSArray<Reward *>* _Nullable rewards);
typedef void (^RewardListAndErrorCallback)(NSArray<Reward *>* _Nullable rewards, NSError* _Nullable error);
typedef void (^ProgressCallback)(NSNumber* progress);


@interface IARNetworkManager : NSObject

/// The singleton `IARNetworkManager` object
+(IARNetworkManager*)shared;

/// Returns the identifier of the external **UserId**
-(NSString*)externalUserId;

/// Creates a new external UserId on the IAR Cloud service
/// @param newId the new external UserId
/// @param completeCallback callback with optional **id string** and optional **error**
/// @discussion This function creates the specified userId on the IAR Cloud and returns it (if succesfull), use the callback 'downloadMarker(markerId:completeCallback:progressCallback)' to retrieve the userId or to check for an error code
-(void)createExternalUserId:(NSString *)newId completeCallback:(CreateExternalUserIdCallback)completeCallback;

/// Sets a new externalUserId - also clears the reward cache from disk
/// @param newId the new external UserId
/// @discussion
/// To avoid the cache clearing operation during user switching, call the following method signature instead:
/// @code
///  - (void) setExternalUserId:(NSString *)newId clearCache:(BOOL) shouldClear;
/// @endcode
-(void)setExternalUserId:(NSString *)newId;

/// Sets a new externalUserId
/// @param newId the new external UserId
/// @param shouldClear defines if current reward and asset cache should be cleared
-(void)setExternalUserId:(NSString *)newId clearCache:(BOOL) shouldClear;

/// Move user rewards from a user to another
/// @param oldUserId the old external UserId
/// @param newUserId  the new external UserId
/// @param completeCallback callback with optional **error**
-(void)migrateDataFrom:(NSString *)oldUserId to:(NSString *) newUserId completeCallback:(MigrateDataCallback)completeCallback;

/// Clears the local filesystem cache (including assets, markets, reward files)
-(void)clearCache;

/// Download a list of all rewards owned by the current user
/// @param completeCallback callback with optional **reward array** and **optional error**
/// @discussion This function retrieves all rewards owned by a user. To receive a reward, the user needs to be logged in and interact with a marker that have rewards
-(void)downloadUserRewards: (RewardListAndErrorCallback)completeCallback;

/// Download a specific marker using an ID
/// @param markerId string representing the marker
/// @param completeCallback callback with optional **marker** and optional **error**
/// @param progressCallback callback that supplies a 0-1 progress indicator downloading the assets and rewards related to the given markerID
/// @discussion This function calls 'downloadAssetsAndRewardsFromMarker(from:completeCallback:progressCallback)' after retrieving the marker.
-(void)downloadMarker: (NSString*)markerId
     completeCallback: (MarkerAndErrorCallback)completeCallback
     progressCallback: (ProgressCallback)progressCallback;


/// Download a specific reward using an ID
/// @param rewardId string representing the reward
/// @param completeCallback callback with optional **reward** and optional **error**
/// @param progressCallback  callback that supplies a 0-1 progress indicator
-(void)downloadReward: (NSString*)rewardId
     completeCallback: (RewardAndErrorCallback)completeCallback
     progressCallback: (ProgressCallback)progressCallback;


/// Download all assets and rewards related to a marker
/// @param marker Full marker object containing the assets and rewards that will be downloaded
/// @param completeCallback callback with optional **marker** and optional **error**
/// @param progressCallback  callback that supplies a 0-1 progress indicator
-(void)downloadAssetsAndRewardsFromMarker: (Marker*)marker
                         completeCallback: (MarkerAndErrorCallback)completeCallback
                         progressCallback: (ProgressCallback)progressCallback;

/// Download all assets related to a marker
/// @param marker Full marker object containing the assets that will be downloaded
/// @param completeCallback callback with optional **marker** and optional **error**
/// @param progressCallback  callback that supplies a 0-1 progress indicator
-(void)downloadAssets: (Marker*)marker
     completeCallback: (MarkerAndErrorCallback)completeCallback
     progressCallback: (ProgressCallback)progressCallback;

/// Download all rewards related to a marker
/// @param marker Full marker object containing the assets that will be downloaded
/// @param completeCallback callback with optional **rewards array** and optional **error**
/// @param progressCallback callback that supplies a 0-1 progress indicator
-(void)downloadRewards: (Marker*)marker
      completeCallback: (RewardListCallback)completeCallback
      progressCallback: (ProgressCallback)progressCallback;

/// Retrieves all of the hunts available
/// @param completeCallback callback with optional **Hunt List** and optional **error**
/// @discussion This function returns an optional **Hunt List** and each of the Hunt contains a list of *huntMarkers*.
/// @see 'Hunt'
-(void)retrieveHunts: (HuntsListAndErrorCallback)completeCallback;

// Retrieves a single hunts details
/// @param huntId  string with the Hunt ID
/// @param completeCallback callback with optional **Hunt List** and optional **error**
/// /// @see 'Hunt'
-(void)retrieveHunt: (NSString*)huntId completeCallback:(HuntAndErrorCallback)completeCallback;


/// Download a list of markers within a certain location
/// @param latitude the users latitude
/// @param longitude the users longitude
/// @param radius  the total radius to check around the location
/// @param completeCallback callback with optional **markers array** and optional **error**
/// @discussion This function retrieves a partially full marker, call 'downloadMarker(markerId:completeCallback:progressCallback)' to retrieve the full marker and download its assets and rewards.
-(void)downloadLocationMarkers: (double)latitude
                     longitude: (double)longitude
                        radius: (double)radius
              completeCallback: (MarkerListAndErrorCallback)completeCallback;


/// Download a list of all markers tagged as 'OnDemand'
/// @param completeCallback callback with optional **markers array** and optional **error**
/// @discussion This function retrieves a partially full marker, call 'downloadMarker(markerId:completeCallback:progressCallback)' to retrieve the full marker and download its assets and rewards.
-(void)downloadOnDemandMarkersWithCallback: (MarkerListAndErrorCallback)completeCallback;

@end


NS_ASSUME_NONNULL_END
