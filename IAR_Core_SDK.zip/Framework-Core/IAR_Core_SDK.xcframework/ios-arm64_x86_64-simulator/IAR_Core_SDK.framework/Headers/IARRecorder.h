//
//  IARRecorder.h
//  IAR Target SDK
//
//  Created by Julia Yamamoto on 2021-02-22.
//  Copyright © 2021 Imagination Park Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^UrlAndErrorCallback)(NSURL* _Nullable url, NSError* _Nullable error);
typedef void (^ProgressCallback)(NSNumber* progress);

@interface IARRecorder : NSObject

/// Start recording audio and frames for the video
/// @param view UIView that will be recorded
/// @return returns an error if a permission is required or a video is already being recorded
-(NSError *_Nullable)startRecordingVideoUsingView:(UIView *)view;

/// Stop recording the audio and frames and compile them into a video
/// @param progress the buffering progress of the video
/// @param completion return the URL of the saved file or an error
-(void)stopRecordingVideo:(ProgressCallback)progress completion:(UrlAndErrorCallback)completion;

/// Cancel video recording and clear memory
-(void)cancelRecordingVideo;

/// Takes a screenshot from a view and returns a UIImage
/// @param view UIView that will be saved into an image. All contents of this view will show at the final image.
/// @return UIImage with the contents of the given view.
-(UIImage *)takeScreenshot: (UIView *)view;


@end

NS_ASSUME_NONNULL_END
