//
//  IARLicenseManager.h
//  IAR
//
//  Created by Wes Goodhoofd on 2020-02-27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, CloudServer) {
    CloudServerUS = 0,
    CloudServerEU
};
typedef NS_ENUM(NSUInteger, VuforiaServer) {
    VuforiaServerProd = 0,
    VuforiaServerDev
};
typedef void (^ErrorCallback)(NSError* _Nullable error);

@interface IARLicenseManager : NSObject

/// Boolean that saves if the current license is valid.
/// @discussion Default value is false. Is set to frue after 'ValidateLicense(_:servertype:OnComplete)' function is called with the correct paramethers.
@property BOOL iarLicenseIsValid;

/// Validate license for ImagineAR using an orgKey
/// @param iarLicense orgkey
/// @param serverType .US or .EU server
/// @param onComplete callback with optional error. Error given back if validation has failed.
-(void)validateLicense: (NSString* _Nonnull)iarLicense
            serverType:(CloudServer)serverType
            onComplete:(ErrorCallback)onComplete;

/// Retrieve the current ImagineAR license
/// @return string with current license being used
-(NSString*)iarLicense;

/// Retrieve the current server type
/// @return current server: .US or .EU
-(CloudServer)getServerType;

/// Retrieve the current server type
/// @return current server: .US or .EU
-(VuforiaServer)getVuforiaServer;

/// Retrieve the current SDK version
/// @return current SDK version and build number. e.g: 1.1.3(6)
-(NSString* _Nonnull)sdkVersion;

/// The singleton `IARLicenseManager` object
+(IARLicenseManager*)shared;

@end

NS_ASSUME_NONNULL_END
