//
//  IAR_SDK.h
//  IAR SDK
//
//  Created by Wes Goodhoofd on 2020-03-13.
//  Copyright © 2020 Imagination Park Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for IAR_SDK.
FOUNDATION_EXPORT double IAR_SDKVersionNumber;

//! Project version string for IAR_SDK.
FOUNDATION_EXPORT const unsigned char IAR_SDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IAR_SDK/PublicHeader.h>

#import "IARNetworkManager.h"
#import "IARLicenseManager.h"
#import "NSObject+Errors.h"
#import "IARRecorder.h"

