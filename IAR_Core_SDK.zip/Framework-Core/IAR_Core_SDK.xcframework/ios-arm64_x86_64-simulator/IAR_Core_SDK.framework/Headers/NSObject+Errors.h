//
//  NSObject+Error.h
//  IAR
//
//  Created by Wes Goodhoofd on 2020-03-04.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, IARErrorCode) {
    
    //License
    IARErrorCodeNoLicenseFileFound = 200,
    IARErrorCodeUnableToParseLicenseFile,
    IARErrorCodeUnableToLoadLicense,
    IARErrorCodeInvalidVuforiaLicense,
    IARErrorCodeInvalidIARLicense,
    IARErrorCodeUnableToVerifyLicense,
    
    //AR
    IARErrorCodeErrorDownloadingMarker,
    IARErrorCodeLoadAsset,
    IARErrorCodeInvalidAsset,
    IARErrorCodeLoadScene,
    IARErrorCodeARTrackingNotSupported,
    IARErrorCodeLowFrameQuality,
    IARErrorCodeFailCreatingTexture,
    
    //Recorder
    IARErrorCodeRecordInit,
    IARErrorCodeErrorRecordFrames,
    IARErrorCodeErrorRecordAudio,
    IARErrorCodeErrorRecordUrl,
    IARErrorCodeErrorRecordVideo,
    
    //Premission
    IARErrorCodeCameraPermissionRequired,
    IARErrorCodeMicrophonePermissionRequired,
    
    //Vuforia
    IARErrorCodeVuforiaInit,
    IARErrorCodeVuforiaInitCamera,
    IARErrorCodeVuforiaStartCamera,
    IARErrorCodeVuforiaStopCamera,
    IARErrorCodeVuforiaDeinitCamera,
    IARErrorCodeVuforiaInitTrackers,
    IARErrorCodeVuforiaLoadTrackerData,
    IARErrorCodeVuforiaStartingTrackers,
    IARErrorCodeVuforiaStoppingTackers,
    IARErrorCodeVuforiaUnloadingTrackerData,
    IARErrorCodeVuforiaDeinitTrackers,
    IARErrorCodeVuforiaInternalError,
    
    //Network
    IARErrorCodeNoNetworkConnection,
    IARErrorCodeRequestTimeout,
    IARErrorCodeCloudRecognition,
    IARErrorCodeLocation,
    
    //ExternalUsers
    IARErrorCodeCreateUserConflict,
    IARErrorCodeUserIdDoesNotExist,
    IARErrorCodeUserIdNotProvided,
    
    //Rewards
    IARErrorCodeDownloadReward,
    
    //Others
    IARErrorCodeGenericError,
    IARErrorCodeSessionInterrupted
};

@interface NSObject (Errors)

-(NSError *)NSErrorWithCode: (IARErrorCode) code;
-(NSError *)NSErrorWithNumber: (NSInteger) code;
-(NSError *)NSErrorWithText: (NSString *) description code: (IARErrorCode)code;
-(NSError *)NSErrorWithText: (NSString *) description number: (NSInteger)code;
-(NSError *)NSErrorWithCode: (IARErrorCode) code error: (NSError **) error;

@end

NS_ASSUME_NONNULL_END
