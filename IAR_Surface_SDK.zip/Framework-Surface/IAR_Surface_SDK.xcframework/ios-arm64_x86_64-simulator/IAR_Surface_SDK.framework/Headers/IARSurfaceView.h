//
//  IARSurfaceView.h
//  IAR SDK
//
//  Created by Andrew Burger on 2020-10-27.
//  Copyright © 2020 Imagination Park Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SceneKit/SceneKit.h>
#import <ARKit/ARKit.h>

@class IARSurfaceView, Marker;

// the AR Application now only receives high level messages
// all processing, loading and displaying is handled internally by the manager
@protocol IARSurfaceViewDelegate

@required

/// Called when a generic error takes place
/// @param surfaceView IARSurfaceView object
/// @param error object containing error information
-(void)surfaceView: (IARSurfaceView* _Nonnull)surfaceView onError: (NSError* _Nonnull)error;

@optional
/// Callback passed by network progress block for indicating that an asset is being downloaded
/// @param surfaceView IARSurfaceView object
/// @param progress percentage 0-1 of how much of the download is complete
-(void)surfaceView: (IARSurfaceView* _Nonnull)surfaceView downloadProgress: (CGFloat)progress;

/// When a surface is detected
/// @param surfaceView IARSurfaceView object
-(void)surfaceViewSurfaceDetected: (IARSurfaceView* _Nonnull)surfaceView;

/// When an asset is anchored
/// @param surfaceView IARSurfaceView object
-(void)surfaceViewAssetAnchored: (IARSurfaceView* _Nonnull)surfaceView;

/// If the AR asset should be showing before the user taps to "place" the asset on an anchor. This is called on `start`
/// @param surfaceView IARSurfaceView object
-(BOOL)surfaceViewOnlyShowAssetOnTap: (IARSurfaceView* _Nonnull)surfaceView;

/// If the AR asset can be scaled by user input
/// @param surfaceView IARSurfaceView object
-(BOOL)surfaceViewCanScaleAsset: (IARSurfaceView* _Nonnull)surfaceView;

@end

NS_ASSUME_NONNULL_BEGIN

/// The view to hold all surface detection and AR experience
@interface IARSurfaceView : UIView <ARSCNViewDelegate, ARSessionDelegate>
@property (nonatomic, weak) NSObject<IARSurfaceViewDelegate>* _Nullable delegate;

/// Load the AR Scene and setup all gestures and parts for the scene
-(void)load;

/// Start the surface detection
-(void)start;

/// Pause the AR experience
-(void)stop;

/// Set the marker to be shown
/// @param marker The marker to be shown for the AR experience
-(void)setMarker: (nonnull Marker*)marker;

/// Unlock the asset from the locked anchor position
-(void)unanchorAsset;

/// Pause the video AR experience
-(void)pauseVideo;

/// Resume the video AR experience
-(void)resumeVideo;

@end

NS_ASSUME_NONNULL_END
