//
//  IARLocationManager.h
//  IAR Surface SDK
//
//  Created by Andrew Burger on 2020-12-08.
//  Copyright © 2020 Imagination Park Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <SceneKit/SceneKit.h>


@class Marker;
@class Reward;

@class IARLocationManager;

// the AR Application now only receives high level messages
// all processing, loading and displaying is handled internally by the manager
@protocol IARLocationManagerDelegate

@required

/// Called when a generic error takes place
/// @param locationManager IARLocationManager object
/// @param error object containing error information
-(void)locationManager: (IARLocationManager* _Nonnull)locationManager onError: (NSError* _Nonnull)error;

@optional
/// Callback passed by network progress block for indicating that an asset is being downloaded
/// @param locationManager IARLocationManager object
/// @param progress percentage 0-1 of how much of the download is complete
-(void)locationManager: (IARLocationManager* _Nonnull)locationManager downloadProgress: (CGFloat)progress;

@end

NS_ASSUME_NONNULL_BEGIN

/// The manager of location markers
@interface IARLocationManager : NSObject
@property (nonatomic, weak) NSObject<IARLocationManagerDelegate>* _Nullable delegate;

-(instancetype _Nonnull)initWithDelegate: (NSObject<IARLocationManagerDelegate>* _Nonnull)aDelegate;

/// Retriece the location markers for a users location that are within the radius
/// @param latitude latitude of the user's location
/// @param longitude longitude of the user's location
/// @param radius radius around the user's location in meters
/// @param callback called once the location markers are downloaded
-(void)getLocationMarkers: (double)latitude longitude: (double)longitude radius: (int)radius callback: (void (^_Nonnull)(NSArray<Marker *>* _Nonnull markers))callback;


/// Download the assets and rewards of a location marker
/// @param marker The marker to download the assets and rewards for
/// @param completeCallback Completion callback
-(void)downloadLocationAssetsAndRewards: (Marker* _Nonnull)marker completeCallback: (void (^_Nonnull)(Marker * _Nullable marker, NSError * _Nullable error))completeCallback;

@end

NS_ASSUME_NONNULL_END
