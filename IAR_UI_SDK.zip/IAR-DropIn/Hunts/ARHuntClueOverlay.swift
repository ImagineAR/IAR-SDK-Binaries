import Foundation
import UIKit
import IAR_Core_SDK

final class ARHuntClueOverlay: OverlayView {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var huntTitle: UILabel!
    @IBOutlet private weak var huntImage: UIImageView!
    @IBOutlet private weak var typeIcon: UIImageView!
    @IBOutlet private weak var typeTitle: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var huntButton: UIButton!
    @IBOutlet private weak var closeButton: UIButton!
    @IBOutlet private weak var typeStack: UIStackView!
    
    private var huntMarker: HuntMarker?

    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        cardView.backgroundColor = .arWhite
        cardView.layer.cornerRadius = 5
        huntImage.clipsToBounds = true
        huntImage.layer.cornerRadius = 5
        huntButton.backgroundColor = ARView.branding.primaryColor
        huntButton.setTitleColor(.arWhite, for: .normal)
        huntButton.tintColor = .arWhite
        huntButton.imageView?.tintColor = .arWhite
        huntButton.layer.cornerRadius = 5
        huntButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        if #available(iOS 13.0, *) {
            closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        } else {
            // Fallback on earlier versions
            closeButton.setTitle("X", for: .normal)
            closeButton.setTitleColor(.arWhite, for: .normal)
        }
        closeButton.tintColor = .arWhite
        closeButton.backgroundColor = .arBlack
        closeButton.clipsToBounds = true
        closeButton.layer.cornerRadius = 24
        typeIcon.tintColor = .arBlack
        huntTitle.textColor = .arBlack
        huntTitle.font = ARView.FontStyle.semibold.font(size: 22)
        typeTitle.textColor = .arBlack
        typeTitle.font = ARView.FontStyle.extrabold.font(size: 17)
        descriptionLabel.textColor = .arBlack
        descriptionLabel.font = ARView.FontStyle.regular.font(size: 15)
    }
    
    func load(huntMarker: HuntMarker) {
        self.huntMarker = huntMarker
        
        if !huntMarker.scanned {
            if #available(iOS 13.0, *) {
                huntButton.setImage(UIImage(systemName: "checkmark"), for: .normal)
            }
            huntButton.setTitle("Hunt Again", for: .normal)
            huntButton.semanticContentAttribute = .forceLeftToRight
            huntButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 25, bottom: 0, right: 20)
            huntButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -20, bottom: 0, right: 0)
        } else {
            if #available(iOS 13.0, *) {
                huntButton.setImage(UIImage(systemName: "arrow.forward"), for: .normal)
            }
            huntButton.setTitle("Hunt for Marker", for: .normal)
            huntButton.semanticContentAttribute = .forceRightToLeft
            huntButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 25)
            huntButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 0)
        }
        
        if let clueDescription = huntMarker.clueCard?.clueDescription {
            descriptionLabel.text = clueDescription
        } else {
            descriptionLabel.isHidden = true
        }
        
        if let url = URL(string: huntMarker.clueCard?.imageUrl ?? "") {
            huntImage.downloaded(from: url)
        } else if let url = URL(string: huntMarker.marker?.previewImageUrl ?? "") {
            huntImage.downloaded(from: url)
        } else {
            huntImage.image = UIImage(named: "hunts-placeholder-image", in: Bundle.arBundle, compatibleWith: nil)
        }
        
        huntTitle.text = huntMarker.clueCard?.name ?? huntMarker.marker?.name ?? "Hunt Marker"
        
        if let markerType = huntMarker.marker?.type {
            typeIcon.image = UIImage.imageFor(type: markerType)
            switch markerType {
            case .image:
                typeTitle.text = "Image Marker"
            case .location:
                typeTitle.text = "Location Marker"
            case .ondemand:
                typeTitle.text = "On-demand Marker"
            case .unknown:
                typeStack.isHidden = true
            @unknown default:
                typeStack.isHidden = true
            }
        } else {
            typeStack.isHidden = true
        }
    }
    
    // MARK: - IBActions
    
    @IBAction private func closeTapped() {
        removeFromSuperview()
    }
    
    @IBAction private func huntTapped() {
        guard let markerType = huntMarker?.marker?.type else {
            return
        }
        
        // TODO: Andrew - cannot present on a presenting controller
        switch markerType {
        case .image:
            ARView.showExperience(.target, on: nil)
        case .location:
            ARView.showExperience(.location, on: nil)
        case .ondemand:
            ARView.showExperience(.surface, marker: huntMarker?.marker, on: nil)
        case .unknown:
            break
        @unknown default:
            break
        }
    }
}
