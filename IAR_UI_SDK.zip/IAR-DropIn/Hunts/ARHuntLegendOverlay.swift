import Foundation
import UIKit
import IAR_Core_SDK

final class ARHuntLegendOverlay: OverlayView {
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var locationIcon: UIImageView!
    @IBOutlet private weak var locationTitle: UILabel!
    @IBOutlet private weak var locationDescription: UILabel!
    @IBOutlet private weak var imageIcon: UIImageView!
    @IBOutlet private weak var imageTitle: UILabel!
    @IBOutlet private weak var imageDescription: UILabel!
    @IBOutlet private weak var onDemandIcon: UIImageView!
    @IBOutlet private weak var onDemandTitle: UILabel!
    @IBOutlet private weak var onDemandDescription: UILabel!
    @IBOutlet private weak var okButton: UIButton!
    
    // MARK: - Setup

    override func setupView() {
        super.setupView()
        
        cardView.backgroundColor = .arWhite
        cardView.layer.cornerRadius = 5
        okButton.backgroundColor = ARView.branding.primaryColor
        okButton.setTitleColor(.arWhite, for: .normal)
        okButton.tintColor = .arWhite
        okButton.layer.cornerRadius = 5
        okButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        
        titleLabel.textColor = .arBlack
        titleLabel.font = ARView.FontStyle.semibold.font(size: 22)
        
        locationIcon.image = UIImage.imageFor(type: .location)
        locationIcon.tintColor = .arBlack
        locationTitle.textColor = .arBlack
        locationTitle.font = ARView.FontStyle.extrabold.font(size: 17)
        locationDescription.textColor = .arBlack
        locationDescription.font = ARView.FontStyle.regular.font(size: 15)
        
        imageIcon.image = UIImage.imageFor(type: .image)
        imageIcon.tintColor = .arBlack
        imageTitle.textColor = .arBlack
        imageTitle.font = ARView.FontStyle.extrabold.font(size: 17)
        imageDescription.textColor = .arBlack
        locationDescription.font = ARView.FontStyle.regular.font(size: 15)
        
        onDemandIcon.image = UIImage.imageFor(type: .ondemand)
        onDemandIcon.tintColor = .arBlack
        onDemandTitle.textColor = .arBlack
        onDemandTitle.font = ARView.FontStyle.extrabold.font(size: 17)
        onDemandDescription.textColor = .arBlack
        onDemandDescription.font = ARView.FontStyle.regular.font(size: 15)
    }
    
    // MARK: - IBActions
    
    @IBAction private func closeTapped() {
        removeFromSuperview()
    }
}
