import UIKit
import IAR_Core_SDK

final class ARHuntCell: NibTableViewCell {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var huntImageView: UIImageView!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var progressBar: ARHuntProgressBar!
    
    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        backgroundColor = .clear
        cardView.backgroundColor = .arGrey700
        cardView.layer.cornerRadius = 5
        nameLabel.textColor = .arWhite
        nameLabel.font = ARView.FontStyle.semibold.font(size: 22)
        descriptionLabel.textColor = .arWhite
        descriptionLabel.font = ARView.FontStyle.regular.font(size: 14)
    }
    
    func load(hunt: Hunt) {
        if let thumbnailString = hunt.thumbnailUrl, let thumbnailURL = URL(string: thumbnailString) {
            huntImageView.downloaded(from: thumbnailURL)
            huntImageView.isHidden = false
        } else {
            huntImageView.isHidden = true
        }
        nameLabel.text = hunt.name
        if let huntDescription = hunt.huntDescription, !huntDescription.isEmpty {
            descriptionLabel.text = huntDescription
            descriptionLabel.isHidden = false
        } else {
            descriptionLabel.isHidden = true
        }
        progressBar.load(hunt: hunt)
    }
}
