import Foundation
import UIKit
import IAR_Core_SDK

final class ARHuntProgressBar: NibView {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var progressLabel: UILabel!
    @IBOutlet private weak var backgroundBar: UIView!
    @IBOutlet private weak var progressBar: UIView!
    
    // MARK: - Setup

    override func setupView() {
        super.setupView()
        
        progressLabel.textColor = .arWhite
        progressLabel.font = ARView.FontStyle.semibold.font(size: 13)
        backgroundBar.layer.borderWidth = 2
        backgroundBar.layer.borderColor = UIColor.arWhite.cgColor
        backgroundBar.backgroundColor = .arBlack
        backgroundBar.layer.cornerRadius = 13
        progressBar.layer.borderWidth = 2
        progressBar.layer.borderColor = UIColor.arWhite.cgColor
        progressBar.backgroundColor = ARView.branding.primaryColor
        progressBar.layer.cornerRadius = 13
    }
    
    func load(hunt: Hunt) {
        let markersRequired = hunt.getNumberOfMarkersForNextReward()
        if markersRequired > 0 {
            progressLabel.text = "\(markersRequired) more markers until the next reward!"
        } else if hunt.isComplete() {
            progressLabel.text = "You have completed this hunt!"
        } else {
            progressLabel.text = "\((hunt.huntMarkers?.count ?? 0) - hunt.getNumberOfMarkersScanned()) more markers until complete!"
        }
        
        NSLayoutConstraint.activate([
            progressBar.widthAnchor.constraint(equalTo: backgroundBar.widthAnchor, multiplier: hunt.getMarkerProgress())
        ])
        
        // TODO: Andrew - reward icons
    }
}
