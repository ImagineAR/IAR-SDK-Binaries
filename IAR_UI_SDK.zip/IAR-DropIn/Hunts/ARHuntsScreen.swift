import Foundation
import UIKit
import IAR_Core_SDK

final class ARHuntsScreen: UIViewController {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var huntsIcon: UIImageView!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var tableView: UITableView!
    
    private var huntsList: [Hunt] = []
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .arBlack
        
        huntsIcon.image = UIImage.imageFor(experience: .hunts)
        huntsIcon.tintColor = .arWhite
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        
        tableView.register(ARHuntCell.self, forCellReuseIdentifier: "ARHuntCell")
        tableView.dataSource = self
        tableView.delegate = self
        
        retrieveHunts()
        
        ARTutorialOverlay.show(experience: .hunts, on: view)
    }
    
    // MARK: - Hunts
    
    private func retrieveHunts() {
        tableView.isARDataLoading = true
        
        IARNetworkManager.shared().retrieveHunts { [weak self] hunts, error in
            guard let self = self else { return }
            DispatchQueue.main.async {
                self.tableView.isARDataLoading = false
                
                if let error = error {
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
                } else {
                    if let hunts = hunts {
                        self.huntsList = hunts
                    } else {
                        self.huntsList = []
                    }
                }
            
                self.tableView.reloadData()
            }
        }
    }
}

extension ARHuntsScreen: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return huntsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ARHuntCell") as? ARHuntCell else {
            return UITableViewCell()
        }
        
        cell.load(hunt: huntsList[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsScreen = ARHuntDetailsScreen(nibName: "ARHuntDetailsScreen", bundle: Bundle.arBundle)
        detailsScreen.hunt = huntsList[indexPath.row]
        navigationController?.pushViewController(detailsScreen, animated: true)
    }
}
