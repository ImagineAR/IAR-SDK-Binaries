import UIKit
import IAR_Core_SDK
import MapKit

class ARHuntDetailsScreen: UIViewController {

    // MARK: - Outlets
    
    @IBOutlet private weak var headerView: UIView!
    @IBOutlet private weak var backButton: UIButton!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var infoButton: UIButton!
    @IBOutlet private weak var huntImage: UIImageView!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var progressBar: ARHuntProgressBar!
    @IBOutlet private weak var collectionContainer: UIView!
    @IBOutlet private weak var tabStack: UIStackView!
    @IBOutlet private weak var markersButton: UIButton!
    @IBOutlet private weak var rewardsButton: UIButton!
    
    @IBOutlet private weak var collectionView: UICollectionView!
    
    // MARK: - Properties

    var hunt: Hunt!
    private var markersSelected = true {
        didSet {
            if oldValue != markersSelected {
                collectionView.reloadData()
            }
        }
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        headerView.backgroundColor = .arBlack.withAlphaComponent(0.7)
        if #available(iOS 13.0, *) {
            backButton.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        } else {
            backButton.setTitle("<", for: .normal)
            backButton.setTitleColor(.arWhite, for: .normal)
        }
        backButton.tintColor = .arWhite
        if #available(iOS 13.0, *) {
            infoButton.setImage(UIImage(systemName: "info.circle"), for: .normal)
        } else {
            infoButton.setTitle("i", for: .normal)
            infoButton.setTitleColor(.arWhite, for: .normal)
        }
        infoButton.tintColor = .arWhite
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        headerLabel.text = hunt.name
        if let thumbnailUrl = URL(string: hunt.thumbnailUrl ?? "") {
            huntImage.downloaded(from: thumbnailUrl)
        } else {
            huntImage.isHidden = true
        }
        descriptionLabel.textColor = .arWhite
        descriptionLabel.font = ARView.FontStyle.regular.font(size: 14)
        descriptionLabel.text = hunt.huntDescription
        markersButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 14)
        markersButton.setTitleColor(.arWhite, for: .normal)
        markersButton.setTitleColor(.arWhite, for: [.normal, .selected])
        markersButton.tintColor = ARView.branding.primaryColor
        rewardsButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 14)
        rewardsButton.setTitleColor(.arWhite, for: .normal)
        rewardsButton.setTitleColor(.arWhite, for: [.normal, .selected])
        rewardsButton.tintColor = ARView.branding.primaryColor
        collectionContainer.layer.cornerRadius = 5
        collectionContainer.clipsToBounds = true
        collectionContainer.layer.borderColor = ARView.branding.secondaryColor.cgColor
        collectionContainer.layer.borderWidth = 1
        tabStack.layer.borderColor = ARView.branding.secondaryColor.cgColor
        tabStack.layer.borderWidth = 1
        progressBar.load(hunt: hunt)
        updateTabBar()
        
        collectionView.contentInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        collectionView.register(ARHuntMarkerRewardCell.self, forCellWithReuseIdentifier: "ARHuntMarkerRewardCell")
        collectionView.dataSource = self
        collectionView.delegate = self
    }
    
    private func updateTabBar() {
        markersButton.backgroundColor = markersSelected ? ARView.branding.secondaryColor : .clear
        rewardsButton.backgroundColor = markersSelected ? .clear : ARView.branding.secondaryColor
    }
    
    // MARK: - IBActions
    
    @IBAction private func onBackButton() {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction private func onInfoButton() {
        ARHuntLegendOverlay().overlay(on: view)
    }
    
    @IBAction private func onMarkersButton() {
        markersSelected = true
        updateTabBar()
    }
    
    @IBAction private func onRewardsButton() {
        markersSelected = false
        updateTabBar()
    }
}

// MARK: - Extensions

extension ARHuntDetailsScreen: UICollectionViewDelegate, UICollectionViewDataSource {
    func requiredScansLeft(reward: HuntReward) -> Int {
        let totalScansRequired = (reward.isCustomProgress ? reward.requiredScanCount?.intValue : hunt.huntMarkers?.count) ?? 0
        return (hunt.huntMarkers?.count ?? 0) - totalScansRequired
    }
    
    // MARK: - Collection View Delegate
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return markersSelected ? hunt.huntMarkers?.count ?? 0 : hunt.huntRewards?.count ?? 0
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ARHuntMarkerRewardCell", for: indexPath) as! ARHuntMarkerRewardCell
        if markersSelected {
            if let marker = hunt.huntMarkers?[indexPath.row] {
                cell.setupCell(marker: marker)
            }
        } else {
            if let reward = hunt.huntRewards?[indexPath.row] {
                cell.setupCell(reward: reward, scansRequired: requiredScansLeft(reward: reward))
            }
        }
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if markersSelected {
            if let huntMarker = hunt.huntMarkers?[indexPath.row] {
                showClueCard(for: huntMarker) // TODO: Andrew - this can show AR experiences which can continue a hunt which possibly invalidates all this UI
            }
        } else {
            if let huntReward = hunt.huntRewards?[indexPath.row], requiredScansLeft(reward: huntReward) <= 0, let reward = huntReward.reward {
                showRewardDetails(reward)
            }
        }
    }
    
    private func showClueCard(for huntMarker: HuntMarker) {
        let clueCardView = ARHuntClueOverlay()
        clueCardView.load(huntMarker: huntMarker)
        clueCardView.overlay(on: view)
    }
}
