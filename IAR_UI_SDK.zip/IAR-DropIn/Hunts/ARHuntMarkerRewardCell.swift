import UIKit
import IAR_Core_SDK

final class ARHuntMarkerRewardCell: NibCollectionViewCell {
    // MARK: - IBOutlets
    
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var detailsLabel: UILabel!
    @IBOutlet private weak var typeContainer: UIView!
    @IBOutlet private weak var typeIcon: UIImageView!
    @IBOutlet private weak var checkmarkOverlay: UIView!
    @IBOutlet private weak var checkmarkImage: UIImageView!
    @IBOutlet private weak var lockOverlay: UIView!
    @IBOutlet private weak var lockImage: UIImageView!
    @IBOutlet private weak var lockLabel: UILabel!
    
    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        backgroundColor = .arWhite
        clipsToBounds = true
        layer.cornerRadius = 5
        typeIcon.tintColor = .arBlack
        typeContainer.backgroundColor = .arWhite
        typeContainer.layer.cornerRadius = 5
        typeContainer.layer.maskedCorners = .layerMaxXMaxYCorner
        checkmarkOverlay.backgroundColor = ARView.branding.primaryColor.withAlphaComponent(0.8)
        if #available(iOS 13.0, *) {
            checkmarkImage.image = UIImage(systemName: "checkmark")
        }
        checkmarkImage.tintColor = .arWhite
        lockOverlay.backgroundColor = .arBlack
        if #available(iOS 13.0, *) {
            lockImage.image = UIImage(systemName: "lock.fill")
        }
        lockImage.tintColor = .arWhite
        lockLabel.textColor = .arWhite
        lockLabel.font = ARView.FontStyle.regular.font(size: 13)
        detailsLabel.textColor = .arBlack
        detailsLabel.font = ARView.FontStyle.regular.font(size: 13)
    }
    
    func setupCell(reward: HuntReward, scansRequired: Int) {
        typeContainer.isHidden = true
        checkmarkOverlay.isHidden = true

        // Show reward image - if any
        if let rewardImage = reward.reward?.file?.image {
            imageView.image = rewardImage
        } else {
            imageView.image = UIImage(named: "rewards-placeholder-image", in: Bundle.arBundle, compatibleWith: nil)
            
            if let imageUrl = reward.reward?.file?.getUrl() {
                imageView.downloaded(from: imageUrl)
            }
        }
        
        lockOverlay.isHidden = scansRequired <= 0
        lockLabel.text = "\(scansRequired) more makers!"
    }
    
    func setupCell(marker: HuntMarker) {
        typeContainer.isHidden = false
        if let type = marker.marker?.type {
            typeIcon.image = UIImage.imageFor(type: type)
            typeContainer.isHidden = typeIcon.image == nil
        }
        imageView.image = UIImage(named: "hunts-placeholder-image", in: Bundle.arBundle, compatibleWith: nil)
        
        checkmarkOverlay.isHidden = !marker.scanned
        lockOverlay.isHidden = true
    }
}
