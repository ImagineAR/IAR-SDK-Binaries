import UIKit

final class ARMarkerCell: NibCollectionViewCell {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var thumbnailImageView: UIImageView!
    
    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        backgroundColor = .arWhite
        clipsToBounds = true
        layer.cornerRadius = 5
        nameLabel.font = ARView.FontStyle.regular.font(size: 13)
        nameLabel.textColor = .arBlack
    }
    
    func setupCell(name: String?, thumbnailUrl: String? = nil) {
        nameLabel.text = name
        
        guard let url = thumbnailUrl, let previewImageUrl = URL(string: url) else {
            thumbnailImageView.image = nil
            return
        }
        
        thumbnailImageView.downloaded(from: previewImageUrl)
    }}
