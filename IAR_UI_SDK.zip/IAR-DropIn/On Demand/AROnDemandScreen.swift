import Foundation
import UIKit
import IAR_Core_SDK

final class AROnDemandScreen: UIViewController {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var headerView: UIView!
    @IBOutlet private weak var backButton: UIButton!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var rewardsButton: UIButton!
    @IBOutlet private weak var collectionView: UICollectionView!
    
    private var onDemandMarkerList: [Marker] = []
    
    // MARK: - Setup
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .arBlack
        
        headerView.backgroundColor = .arBlack.withAlphaComponent(0.7)
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        rewardsButton.isHidden = !ARView.availableExperiences.contains(.rewards)
        rewardsButton.setupCircleButton(experience: .rewards)
        if #available(iOS 13.0, *) {
            backButton.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        } else {
            backButton.setTitle("<", for: .normal)
        }
        backButton.tintColor = .arWhite
        
        collectionView.register(ARMarkerCell.self, forCellWithReuseIdentifier: "ARMarkerCell")
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 20, right: 20)
        
        getOnDemandMarkers()
        
        ARTutorialOverlay.show(experience: .onDemand, on: view)
    }
    
    // MARK: - IBActions
    
    @IBAction private func onBackButton() {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction private func onRewardsButton() {
        ARView.showExperience(.rewards, on: navigationController)
    }
    
    // MARK: - Marker Data Handling
    
    private func getOnDemandMarkers() {
        collectionView.isARDataLoading = true
        // Call to fetch all On Demand Markers under the current OrgKey
        IARNetworkManager.shared().downloadOnDemandMarkers { [weak self] markers, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.collectionView.isARDataLoading = false
                if let error = error {
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
                    
                } else {
                    guard let markerList = markers else { return }
                    self.onDemandMarkerList = markerList
                    
                    // Update the table view with the retrieved markers.
                    self.collectionView.reloadData()
                }
            }
        }
    }
    
    private func retrieveMarker(_ id: String) {
        isShowingLoadingARView = true
        
        // Will try to find and show the marker by ID
        IARNetworkManager.shared().downloadMarker(id) { [weak self] marker, error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isShowingLoadingARView = false
                
                // If it couldn't find, show a message
                guard let marker = marker else {
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error?.localizedDescription])
                    return
                }
                
                ARView.showExperience(.surface, marker: marker, on: self.navigationController)
            }
        } progressCallback: { _ in }
    }
}

extension AROnDemandScreen: UICollectionViewDelegate, UICollectionViewDataSource {
    
    // MARK: - Collection View Delegate
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return onDemandMarkerList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ARMarkerCell", for: indexPath) as! ARMarkerCell
        
        let marker = onDemandMarkerList[indexPath.row]
        cell.setupCell(name: marker.name, thumbnailUrl: marker.previewImageUrl)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        retrieveMarker(onDemandMarkerList[indexPath.row].markerId)
    }
}
