import Foundation
import UIKit
import IAR_Core_SDK

final class ARRewardsScreen: UIViewController {
    // UI Elements
    @IBOutlet private weak var rewardsIcon: UIImageView!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var collectionView: UICollectionView!
    
    private var userRewardList: [Reward] = []
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .arBlack
        
        rewardsIcon.image = UIImage.imageFor(experience: .rewards)
        rewardsIcon.tintColor = .arWhite
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        
        collectionView.register(ARRewardCell.self, forCellWithReuseIdentifier: "ARRewardCell")
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 20, right: 20)
        
        retrieveRewards()
    }
    
    // MARK: - Rewards
    
    private func retrieveRewards() {
        collectionView.isARDataLoading = true
        
        IARNetworkManager.shared().downloadUserRewards { [weak self] userRewards, error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.collectionView.isARDataLoading = false
                
                if let error = error {
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
                } else {
                    if let userRewards = userRewards {
                        self.userRewardList = userRewards
                    } else {
                        self.userRewardList = []
                    }
                }
                
                self.collectionView.reloadData()
            }
        }
    }
}

extension ARRewardsScreen: UICollectionViewDelegate, UICollectionViewDataSource {
    // MARK: - Collection View Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return userRewardList.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ARRewardCell", for: indexPath) as! ARRewardCell
        
        cell.setupCell(reward: userRewardList[indexPath.row])
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        showRewardDetails(userRewardList[indexPath.row])
    }
}
