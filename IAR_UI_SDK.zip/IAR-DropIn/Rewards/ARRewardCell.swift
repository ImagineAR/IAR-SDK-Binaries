import UIKit
import IAR_Core_SDK

final class ARRewardCell: NibCollectionViewCell {

    // MARK: - IBOutlets
    
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var typeImageView: UIImageView!
    @IBOutlet private weak var typeContainer: UIView!
    @IBOutlet private weak var detailsLabel: UILabel!
    
    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        backgroundColor = .arWhite
        clipsToBounds = true
        layer.cornerRadius = 5
        
        detailsLabel.textColor = .arBlack
        detailsLabel.font = ARView.FontStyle.regular.font(size: 13)
        
        typeImageView.tintColor = .arBlack
        typeContainer.backgroundColor = .arWhite
        typeContainer.layer.cornerRadius = 5
        typeContainer.layer.maskedCorners = .layerMaxXMaxYCorner
        
    }
    
    func setupCell(reward: Reward) {
        // Show reward type - if any
        let rewardType = reward.reasonType
        if let rewardReasonType = Reward.RewardType(rawValue: rewardType) {
            typeContainer.isHidden = false

            switch rewardReasonType {
            case .Hunt:
                typeImageView.image = UIImage.imageFor(experience: .hunts)
            default:
                typeContainer.isHidden = true
            }
        }

        // Show reward image - if any
        imageView.image = UIImage(named: "rewards-placeholder-image", in: Bundle.arBundle, compatibleWith: nil)
        let rewardUrl = reward.isImage ? reward.file?.getUrl() : nil
        if let imageUrl = rewardUrl {
            imageView.downloaded(from: imageUrl)
        }
    }
}
