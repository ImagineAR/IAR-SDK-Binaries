import Foundation
import UIKit
import IAR_Core_SDK

final class ARRewardOverlay: OverlayView {
    
    // MARK: - IBActions
    
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var typeContainer: UIView!
    @IBOutlet private weak var typeStack: UIStackView!
    @IBOutlet private weak var typeIcon: UIImageView!
    @IBOutlet private weak var typeLabel: UILabel!
    @IBOutlet private weak var contentStack: UIStackView!
    @IBOutlet private weak var promoStack: UIStackView!
    @IBOutlet private weak var promoTitle: UILabel!
    @IBOutlet private weak var promoLabel: UILabel!
    @IBOutlet private weak var copyButton: UIButton!
    @IBOutlet private weak var rewardImage: UIImageView!
    @IBOutlet private weak var rewardTitle: UILabel!
    @IBOutlet private weak var rewardDescription: UILabel!
    @IBOutlet private weak var websiteButton: UIButton!
    @IBOutlet private weak var closeButton: UIButton!
    @IBOutlet private weak var shareButton: UIButton!
    
    private var reward: Reward?
    
    // MARK: - Setup

    override func setupView() {
        super.setupView()
        
        cardView.backgroundColor = .arWhite
        cardView.layer.cornerRadius = 5
        rewardImage.clipsToBounds = true
        rewardImage.layer.cornerRadius = 5
        websiteButton.backgroundColor = ARView.branding.primaryColor
        websiteButton.setTitleColor(.arWhite, for: .normal)
        websiteButton.tintColor = .arWhite
        websiteButton.imageView?.tintColor = .arWhite
        websiteButton.layer.cornerRadius = 5
        websiteButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        if #available(iOS 13.0, *) {
            websiteButton.setImage(UIImage(systemName: "arrow.up.forward.circle"), for: .normal)
        }
        copyButton.setTitleColor(.arBlack, for: .normal)
        copyButton.tintColor = .arBlack
        copyButton.imageView?.tintColor = .arBlack
        copyButton.layer.cornerRadius = 5
        copyButton.layer.borderColor = UIColor.arBlack.cgColor
        copyButton.layer.borderWidth = 1
        copyButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 18)
        if #available(iOS 13.0, *) {
            copyButton.setImage(UIImage(systemName: "square.on.square"), for: .normal)
        }
        shareButton.setTitleColor(.arWhite, for: .normal)
        shareButton.tintColor = .arWhite
        shareButton.imageView?.tintColor = .arWhite
        shareButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        if #available(iOS 13.0, *) {
            shareButton.setImage(UIImage(systemName: "square.and.arrow.up"), for: .normal)
        }
        if #available(iOS 13.0, *) {
            closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        } else {
            closeButton.setTitle("X", for: .normal)
            closeButton.setTitleColor(.arWhite, for: .normal)
        }
        closeButton.tintColor = .arWhite
        closeButton.backgroundColor = .arBlack
        closeButton.clipsToBounds = true
        closeButton.layer.cornerRadius = 24
        
        promoTitle.textColor = .arBlack
        promoTitle.font = ARView.FontStyle.regular.font(size: 14)
        promoLabel.textColor = .arBlack
        promoLabel.font = ARView.FontStyle.semibold.font(size: 20)
        rewardTitle.textColor = .arBlack
        rewardTitle.font = ARView.FontStyle.semibold.font(size: 22)
        rewardDescription.textColor = .arBlack
        rewardDescription.font = ARView.FontStyle.regular.font(size: 18)
        
        typeContainer.layer.borderColor = UIColor.arBlack.cgColor
        typeContainer.layer.borderWidth = 1
        typeContainer.layer.cornerRadius = 5
        typeContainer.layer.maskedCorners = .layerMaxXMaxYCorner
        typeIcon.tintColor = .arBlack
        typeLabel.textColor = .arBlack
        typeLabel.font = ARView.FontStyle.semibold.font(size: 10)
    }
    
    func load(reward: Reward) {
        self.reward = reward
        
        if reward.isPromo {
            promoStack.isHidden = false
            promoLabel.text = reward.generalPromoCode?.promoCode
        } else {
            promoStack.isHidden = true
        }
        
        if reward.isImage {
            rewardImage.isHidden = false
            rewardTitle.isHidden = false
            shareButton.isHidden = false
            if let image = reward.file?.image {
                rewardImage.image = image
            } else if let imageUrl = reward.file?.getUrl() {
                rewardImage.downloaded(from: imageUrl)
            }
        } else {
            rewardImage.isHidden = true
            rewardTitle.isHidden = true
            shareButton.isHidden = true
        }
        
        rewardDescription.text = reward.generalPromoCode?.optionalText
        rewardDescription.isHidden = rewardDescription.text?.isEmpty ?? true
        
        if reward.actionButtonEnabled {
            websiteButton.isHidden = false
            websiteButton.setTitle(reward.actionButtonText, for: .normal)
        } else {
            websiteButton.isHidden = true
        }
        
        if let rewardReasonType = Reward.RewardType(rawValue: reward.reasonType) {
            typeContainer.isHidden = false

            switch rewardReasonType {
            case .Hunt:
                typeIcon.image = ARView.ARExperiences.hunts.icon
                typeLabel.text = ARView.ARExperiences.hunts.name.uppercased()
            default:
                typeContainer.isHidden = true
            }
        } else {
            typeContainer.isHidden = true
        }
    }
    
    // MARK: - IBActions
    
    @IBAction private func closeTapped() {
        removeFromSuperview()
    }
    
    @IBAction private func websiteTapped() {
        guard let urlString = reward?.actionButtonUrl, let url = URL(string: urlString) else { return }
        
        UIApplication.shared.open(url)
    }
    
    @IBAction private func copyTapped() {
        UIPasteboard.general.string = reward?.generalPromoCode?.promoCode
    }
    
    @IBAction private func shareTapped() {
        guard let image = reward?.file?.image else { return }
        
        guard let viewController = Utils.topViewController() else {
            NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: "Failed to get view controller to show share sheet."])
            return
        }
        let ActivityController = UIActivityViewController(activityItems: [image], applicationActivities: nil)
        viewController.present(ActivityController, animated: true, completion: nil)
    }
}
