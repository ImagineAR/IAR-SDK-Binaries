import UIKit
import IAR_Core_SDK

final class ARLocationCell: NibCollectionViewCell {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var distanceLabel: UILabel!
    @IBOutlet private weak var distanceView: UIView!

    private var isNearby: Bool = false
    private var distanceNumber: Double = 0.0 {
        didSet {
            if (isNearby) {
                distanceLabel.font = ARView.FontStyle.extrabold.font(size: 18)
                distanceLabel.text = "NEARBY"
                distanceLabel.textColor = .arWhite
                distanceView.backgroundColor = ARView.branding.primaryColor
            } else {
                distanceLabel.font = ARView.FontStyle.semibold.font(size: 17)
                if distanceNumber > 1000 {
                    distanceLabel.text = String(format: "%.1fkm away", distanceNumber / 1000.0)
                } else {
                    distanceLabel.text = String(format: "%.1fm away", distanceNumber)
                }
                distanceLabel.textColor = .arBlack
                distanceView.backgroundColor = .arWhite
            }
        }
    }
    
    // MARK: - Setup
    
    func setupCell(mapMarker: MapMarker, distance: Double?) {
        if let location: Location = mapMarker.marker.location {
            isNearby = location.isNearby()
        } else {
            isNearby = false
        }
        
        distanceNumber = distance ?? 0
        
        imageView.image = UIImage(named: "MapScreen DefaultIcon", in: Bundle.arBundle, compatibleWith: nil)
        
        if let markerThumbnail = mapMarker.marker.previewImageUrl, let thumbnailURL = URL(string: markerThumbnail) {
            imageView.downloaded(from: thumbnailURL)
        }
    }
}
