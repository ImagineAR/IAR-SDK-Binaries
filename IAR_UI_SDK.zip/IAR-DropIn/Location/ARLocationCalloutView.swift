import UIKit

final class ARLocationCalloutView: NibView {
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var imageContainer: UIView!

    override func setupView() {
        super.setupView()
        
        imageContainer.layer.borderColor = UIColor.arBlack.cgColor
        imageContainer.layer.borderWidth = 4
        imageContainer.layer.cornerRadius = 8
        
        imageView.layer.cornerRadius = 8
    }
    
    func load(imageUrl: String?) {
        imageView.image = UIImage(named: "MapScreen DefaultIcon", in: Bundle.arBundle, compatibleWith: nil)
        
        if let imageUrl = imageUrl, let thumbnailUrl = URL(string: imageUrl) {
            imageView.downloaded(from: thumbnailUrl)
        }

    }
}
