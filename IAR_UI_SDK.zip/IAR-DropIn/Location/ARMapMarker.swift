import UIKit
import MapKit
import IAR_Core_SDK

class UserAnnotation : NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D

    override init() {
        self.coordinate = CLLocationCoordinate2D()
    }
}

class MapMarker: NSObject, MKAnnotation {
    
    var markerId: String
    
    var coordinate: CLLocationCoordinate2D {
        get {
            if let lat = marker.location?.latitude, let long = marker.location?.longitude {
                return CLLocationCoordinate2D(latitude: lat, longitude: long)
            }

            return CLLocationCoordinate2D()
        }
    }

    var radius: Double {
        get {
            if let radius = marker.location?.radius {
                return Double(radius)
            }

            return 0.0
        }
    }
    
    var zIndex: Int = 0

    var title: String? {
        get { return marker.name }
    }

    var subtitle: String? {
        get { return nil }
    }
    
    override var debugDescription: String {
        return "MapMarker - Coords: [ \(coordinate) ], Radius: [ \(radius) ], Title: [\(String(describing: title))] \n"
    }

    var marker: Marker!

    init(marker: Marker) {
        self.markerId = marker.markerId
        self.marker = marker
    }
}

class MarkerCircle: MKCircle {
    var marker: Marker

    convenience override init() {
        self.init()
    }

    static func initMarkerCircle(coord: CLLocationCoordinate2D, radius: CLLocationDistance, marker: Marker) -> MarkerCircle {
        let circle: MarkerCircle = MarkerCircle(center: coord, radius: radius)
        circle.marker = marker

        return circle
    }
}

class MapMarkerViewModel {
    let markerId: String
    var mapMarker: MapMarker
    var markerCircle: MarkerCircle?
    var calloutView: ARLocationCalloutView?
    var annotationView: MKAnnotationView?
    
    var isNearby: Bool {
        mapMarker.marker.location?.isNearby() ?? false
    }
    
    var zIndex: Int = 0
    
    init(marker: MapMarker) {
        self.markerId = marker.markerId
        self.mapMarker = marker
    }
}
