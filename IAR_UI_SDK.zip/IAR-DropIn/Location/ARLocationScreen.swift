import UIKit
import IAR_Core_SDK
import IAR_Surface_SDK
import MapKit

final class ARLocationScreen: UIViewController {

    // MARK: - Outlets
    
    @IBOutlet private weak var headerView: UIView!
    @IBOutlet private weak var homeButton: UIButton!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var rewardsButton: UIButton!
    @IBOutlet private weak var centerButton: UIButton!
    @IBOutlet private weak var huntsButton: UIButton!
    @IBOutlet private weak var mapView: MKMapView!
    @IBOutlet private weak var collectionContainer: UIView!
    @IBOutlet private weak var collectionHeader: UILabel!
    @IBOutlet private weak var emptyCollectionLabel: UILabel!
    @IBOutlet private weak var collectionView: UICollectionView!
    
    // MARK: - Properties

    private var markers = [String : MapMarkerViewModel]()
    private var sortedMarkers: [MapMarkerViewModel] {
        sorted(mapMakers: (markers.map { return $0.value }))
    }
    
    private var locationManager: CLLocationManager = CLLocationManager()
    private var lastMarkerCall: Date?
    private var lastUsedLocation: CLLocation?
    private var lastAccuracy: CLLocationAccuracy = Double.greatestFiniteMagnitude
    
    private var currentUserLocation: CLLocation? {
        didSet {
            if oldValue == nil && currentUserLocation != nil {
                centerMap()
            }
            
            loadLocation()
        }
    }

    private var numberARLocations: Int = 0 {
        didSet {
            collectionHeader.text = "\(numberARLocations) AR Locations near me"
            emptyCollectionLabel.isHidden = numberARLocations != 0
            collectionView.isHidden = !emptyCollectionLabel.isHidden
        }
    }

    private var userAnnotation = UserAnnotation()
    private var radiusLimit = 10000.0
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        headerView.backgroundColor = .arBlack.withAlphaComponent(0.7)
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        rewardsButton.isHidden = !ARView.availableExperiences.contains(.rewards)
        huntsButton.isHidden = !ARView.availableExperiences.contains(.hunts)
        homeButton.isHidden = !ARView.availableExperiences.contains(.homeScreen)
        rewardsButton.setupCircleButton(experience: .rewards)
        huntsButton.setupCircleButton(experience: .hunts)
        homeButton.setImage(UIImage.imageFor(experience: .homeScreen), for: .normal)
        homeButton.tintColor = .arWhite
        centerButton.setImage(UIImage(named: "centre map", in: Bundle.arBundle, compatibleWith:  nil), for: .normal)
        centerButton.backgroundColor = .arWhite
        centerButton.tintColor = .arBlack
        centerButton.layer.cornerRadius = 24
        centerButton.layer.borderWidth = 2
        centerButton.layer.borderColor = UIColor.arBlack.cgColor
        collectionHeader.textColor = .arWhite
        collectionHeader.font = ARView.FontStyle.semibold.font(size: 17)
        emptyCollectionLabel.textColor = .arWhite
        emptyCollectionLabel.font = ARView.FontStyle.regular.font(size: 13)
        
        registerCell()
        mapView.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers
        locationManager.startUpdatingLocation()
        currentUserLocation = locationManager.location
        numberARLocations = 0
        
        ARTutorialOverlay.show(experience: .location, on: view)

        if !CLLocationManager.locationServicesEnabled() {
            showPermissionOverlay(.location)
        }
        
        getLocationMarkers()
    }
    
    // MARK: - Setup
    
    private func registerCell() {
        collectionView.register(ARLocationCell.self, forCellWithReuseIdentifier: "ARLocationCell")
        collectionView.dataSource = self
        collectionView.delegate = self
    }
    
    // MARK: - IBActions
    
    @IBAction private func centerMap() {
        guard let currentUserLocation = currentUserLocation else {
            return
        }
        
        let region = mapView.regionThatFits(MKCoordinateRegion(center: currentUserLocation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500))
        mapView.setRegion(region, animated: true)
    }
    
    @IBAction private func onHomeButton() {
        ARView.showExperience(.homeScreen, on: navigationController)
    }
    
    @IBAction private func onRewardsButton() {
        ARView.showExperience(.rewards, on: navigationController)
    }
    
    @IBAction private func onHuntsButton() {
        ARView.showExperience(.hunts, on: navigationController)
    }
    
    // MARK: - Location Markers
    
    private func removeUserMarkers() {
        mapView.removeAnnotation(userAnnotation)
    }

    private func addUserMarkers() {
        mapView.addAnnotation(userAnnotation)
    }
    
    /// Returns true if last location call was made 30 or more seconds ago OR if the current location is 50m or more from last location
    private func shouldLoadNewMarkers() -> Bool {
        guard let lastAPICall = lastMarkerCall,
              let lastLocation = lastUsedLocation,
              let newLocation = currentUserLocation else {
            return true
        }
        
        let timeDelta: TimeInterval = Date().timeIntervalSinceReferenceDate - lastAPICall.timeIntervalSinceReferenceDate
        let coordinateDelta = newLocation.distance(from: lastLocation)
        let currentAccuracy = newLocation.horizontalAccuracy
        
        if (currentAccuracy <= lastAccuracy) || (lastAccuracy == 0) {
            self.lastAccuracy = currentAccuracy
            let willReturn = (timeDelta > 30) || (coordinateDelta > 15)
            
            return willReturn
        } else {
            // decreased accuracy won't be accepted
            return false
        }
    }
    
    private func loadLocation() {
        // Only when this is the top view controller
        guard self.navigationController?.topViewController == self else {
            return
        }
        guard shouldLoadNewMarkers() else {
            return
        }
        
        removeUserMarkers()
        
        // Get user location and update the markers
        guard let location = currentUserLocation else { return }
        
        userAnnotation = UserAnnotation()
        userAnnotation.coordinate = location.coordinate
        lastUsedLocation = location
        addUserMarkers()
        
        lastMarkerCall = Date()
        
        getLocationMarkers()
    }
    
    private func getLocationMarkers() {
        guard let latitude = currentUserLocation?.coordinate.latitude, let longitude = currentUserLocation?.coordinate.longitude else {
            return
        }
        // Call to fetch all Location Markers under the current OrgKey
        IARNetworkManager.shared().downloadLocationMarkers(latitude, longitude: longitude, radius: radiusLimit) { [weak self] markers, error in
            if let error = error {
                NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
            } else {
                self?.updateMarkers(updatedMarkers: markers ?? [])
            }
        }
    }
    
    private func sorted(mapMakers: [MapMarkerViewModel]) -> [MapMarkerViewModel] {
        
        let sortingClosure: ((MapMarkerViewModel, MapMarkerViewModel) -> Bool) = { rhs, lhs in
            // distance in meters: as floating, the value is changing too often
            // to have a stable order, distance will be compared as integer, in steps of 3m
            // and when equal, the defining factor will be the markerId
            let rhsDistance = Int(rhs.mapMarker.marker.location!.distance) / 3
            let lhsDistance = Int(lhs.mapMarker.marker.location!.distance) / 3
                        
            if (rhsDistance == lhsDistance) {
                return rhs.markerId < lhs.markerId
            } else {
                return rhsDistance < lhsDistance
            }
        }

        let mapMakersNear: [MapMarkerViewModel] = mapMakers
            .filter{ $0.isNearby == true}
            .sorted(by: sortingClosure)
        let mapMakersNotNear: [MapMarkerViewModel] = mapMakers
            .filter{ $0.isNearby == false}
            .sorted(by: sortingClosure)
        let allMarkers = [mapMakersNear, mapMakersNotNear].flatMap{$0}
        
        let returnMarkers: [MapMarkerViewModel] = allMarkers.enumerated().map {
            $1.zIndex = $0
            return $1
        }
        
        return returnMarkers
    }
    
    private func updateMarkers(updatedMarkers: [Marker]) {
        // Remove markers that does not exist anymore
        let markerIds = updatedMarkers.map { $0.markerId }
        let removedMarkers = markers.filter { !markerIds.contains( $1.markerId ) }
        
        removedMarkers.forEach {
            mapView.removeAnnotation($1.mapMarker)
            if let markerCircle = $1.markerCircle {
                mapView.removeOverlay(markerCircle)
            }
        }
        
        updatedMarkers.forEach {
            if let existing = markers[$0.markerId] {
                // Verify updates if any
                // Should only affect model changes during live session
            } else {
                let mapMarker = MapMarker(marker: $0)
                let newMarkerViewModel = MapMarkerViewModel(marker: mapMarker)
                let newCalloutView = setupCalloutView(mapMarker: mapMarker)

                let position = mapMarker.coordinate
                let mapMarkerCircle = MarkerCircle.initMarkerCircle(coord: position,
                                                                                radius: CLLocationDistance(mapMarker.radius),
                                                                                marker: mapMarker.marker)
                newMarkerViewModel.markerCircle = mapMarkerCircle
                newMarkerViewModel.annotationView = setUpMarkerAnnotationView(mapMarker: mapMarker)
                newMarkerViewModel.calloutView = newCalloutView
                
                positionCalloutView(annotationCalloutView: newCalloutView, inRelationTo: newMarkerViewModel.annotationView)
                
                mapView.addAnnotation(mapMarker)
                mapView.addOverlay(mapMarkerCircle)
                
                markers[$0.markerId] = newMarkerViewModel
            }
        }
        
        numberARLocations = markers.count
        collectionView.reloadData()
    }
    
    private func setupCalloutView(mapMarker: MapMarker) -> ARLocationCalloutView {
        let annotationCalloutView = ARLocationCalloutView(frame: CGRect(x: 0, y: 0, width: 80, height: 70))
        annotationCalloutView.load(imageUrl: mapMarker.marker.previewImageUrl)
        return annotationCalloutView
    }
    
    private func positionCalloutView(annotationCalloutView: ARLocationCalloutView, inRelationTo annotationView: MKAnnotationView?) {
        guard let annotationView = annotationView else {
            return
        }
        annotationCalloutView.center = CGPoint(x: annotationView.bounds.size.width / 2, y: -annotationCalloutView.bounds.size.height / 2)

        if !annotationView.subviews.contains(annotationCalloutView) {
            annotationView.addSubview(annotationCalloutView)
        }
    }
    
    private func setUpMarkerAnnotationView(mapMarker: MapMarker) -> MKAnnotationView {
        let annotationView = MKAnnotationView(annotation: mapMarker,
                                              reuseIdentifier: "annotationView")
        annotationView.canShowCallout = false

        // Setup frame annotation view
        annotationView.frame = CGRect(x: 0, y: 0, width: 24, height: 24)
        annotationView.backgroundColor = UIColor.white
        annotationView.alpha = 1
        annotationView.layer.cornerRadius = (annotationView.frame.size.width) / 2
        
        // Setup frame center view
        let centerView = UIView(frame: CGRect(x: 0, y: 0, width: 18, height: 18))
        centerView.backgroundColor = ARView.branding.secondaryColor
        centerView.layer.borderWidth = 3
        centerView.layer.borderColor = UIColor.arBlack.cgColor
        centerView.layer.cornerRadius = (centerView.frame.size.width)/2
        centerView.center = annotationView.center
        annotationView.addSubview(centerView)
        
        return annotationView
    }
    
    private func userDistance(from coordinate: CLLocationCoordinate2D) -> Double? {
        guard let userLocation = self.currentUserLocation else {
            return nil // User location unknown!
        }
        let pointLocation = CLLocation(
            latitude:  coordinate.latitude,
            longitude: coordinate.longitude
        )
        return userLocation.distance(from: pointLocation)
    }
    
    private func retrieveMarker(_ id: String) {
        isShowingLoadingARView = true
        
        // Will try to find and show the marker by ID
        IARNetworkManager.shared().downloadMarker(id) { [weak self] marker, error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                self.isShowingLoadingARView = false
                // If it couldn't find, show a message
                guard let marker = marker else {
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error?.localizedDescription])
                    return
                }
                
                ARView.showExperience(.surface, marker: marker, on: self.navigationController)
            }
        } progressCallback: { _ in }
    }
}

// MARK: - Extensions

extension ARLocationScreen: UICollectionViewDelegate, UICollectionViewDataSource {
    // MARK: - Collection View Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.numberARLocations
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ARLocationCell", for: indexPath) as! ARLocationCell
        let model = sortedMarkers[indexPath.row]
        cell.setupCell(mapMarker: model.mapMarker, distance: userDistance(from: model.mapMarker.coordinate))
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        retrieveMarker(sortedMarkers[indexPath.row].markerId)
    }
}

extension ARLocationScreen: MKMapViewDelegate {
    func findAnnotation(for marker: MapMarker) -> MKAnnotationView {
        guard let annotationView = markers.filter ({ $0.value.mapMarker == marker }).first?.value.annotationView else {
            fatalError("Internal inconsistency")
        }
        return annotationView
    }
    
    // MARK: - Map View Delegate
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation.isKind(of: UserAnnotation.self) {
            // User Annotation
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "userLocation")
            if annotationView == nil {
                annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "userLocation")
            } else {
                annotationView?.annotation = annotation
            }
            
            guard let annotationView = annotationView else { return nil }
            
            annotationView.frame = CGRect(x: 0, y: 0, width: 24, height: 24)
            annotationView.alpha = 1
            annotationView.layer.borderWidth = 3
            annotationView.layer.borderColor = UIColor.arWhite.cgColor
            annotationView.backgroundColor = .arBlack
            annotationView.layer.cornerRadius = (annotationView.frame.size.width) / 2

            return annotationView
        }
        
        if annotation.isKind(of: MKUserLocation.self) {
            return nil
        }
        
        // MapMarker Annotation
        let annotationView = findAnnotation(for: annotation as! MapMarker)
        return annotationView
    }

    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        var circleRenderer = MKCircleRenderer()
        var isNearby = false
        var isLargeCircle = false
        
        if let markerCircle = overlay as? MarkerCircle {
            if let location = markerCircle.marker.location {
                isNearby = location.isNearby()
                isLargeCircle = Double(location.radius) >= radiusLimit
            }
        }

        if let overlay = overlay as? MKCircle {
            circleRenderer = MKCircleRenderer(circle: overlay)
            circleRenderer.path = overlay.accessibilityPath?.cgPath
            circleRenderer.strokeColor = ARView.branding.secondaryColor
            circleRenderer.fillColor = ARView.branding.secondaryColor
            circleRenderer.lineWidth = 2
            circleRenderer.alpha = 0.1
            circleRenderer.lineJoin = .round
            
            // There is a performance issue with using a dash pattern on large circles
            if !isLargeCircle {
                circleRenderer.lineDashPattern = [1, 5]
            }
        }

        return circleRenderer
    }
}

extension ARLocationScreen: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // determine distance from current user
        var allLocations: [CLLocation] = locations
        allLocations = allLocations.sorted { $0.horizontalAccuracy < $1.horizontalAccuracy }
        guard let location = allLocations.first else {
            print("Returned <no location>")
            return
        }
        
        currentUserLocation = location
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {}

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if !CLLocationManager.locationServicesEnabled() {
            // Case location services turned off
            showPermissionOverlay(.location)
        } else {
            switch status {
                case .notDetermined:
                    manager.requestWhenInUseAuthorization()
                case .denied, .restricted:
                    showPermissionOverlay(.location)
                case .authorizedAlways, .authorizedWhenInUse:
                    manager.requestLocation()
                default:
                    break
            }
        }
    }
}


