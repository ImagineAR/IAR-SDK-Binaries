import Foundation
import UIKit
import IAR_Core_SDK
import IAR_Surface_SDK

final class ARSurfaceScreen: UIViewController {
    
    private enum SurfaceState {
        case findingSurface
        case placingActivation
        case activationShowing
    }
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var surfaceView: IARSurfaceView!
    @IBOutlet private weak var headerView: UIView!
    @IBOutlet private weak var backButton: UIButton!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var rewardsButton: UIButton!
    @IBOutlet private weak var huntsButton: UIButton!
    @IBOutlet private weak var messageView: UIView!
    @IBOutlet private weak var messageImage: UIImageView!
    @IBOutlet private weak var messageLabel: UILabel!
    @IBOutlet private weak var moveButton: UIButton!
    @IBOutlet private weak var captureButton: UIImageView!
    
    // MARK: - Properties
    
    private var circularProgressView: ARCircularProgressView!
    private var duration: TimeInterval = 30
    
    private var currentSurfaceState: SurfaceState = .findingSurface {
        didSet {
            currentStateStep = 0
            updateStateUI()
        }
    }
    private var currentStateStep = 0
    private var messageTimer: Timer?
    var marker: Marker?
    private var currentRecordingTime = 0
    private var screenshotTaker = IARRecorder()
    private var recorderOptions: SurfaceRecorder.Options {
        var baseOptions = SurfaceRecorder.Options.default
        let scale = UIScreen.main.scale
        let width = surfaceView.bounds.size.width * scale
        let height = surfaceView.bounds.size.height * scale

        baseOptions.videoSize = CGSize(width: width, height: height)
        return baseOptions
    }
    private lazy var recorderV2 = try? SurfaceRecorder(withSurfaceView: surfaceView, options: recorderOptions)
    
    // Makes sure disposal only happens when the view is being popped from the navigation stack,
    // and not when another view is pushed into it
    private var isAboutToClose: Bool {
        return self.isBeingDismissed ||
               self.isMovingFromParent ||
               self.navigationController?.isBeingDismissed ?? false
    }
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupPermissions()
        startAR()
        
        updateStateUI()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        pauseAR()
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        if isAboutToClose {
            dispose()
        }
        
        super.viewDidDisappear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        resumeAR()
        super.viewWillAppear(animated)
    }
    
    // MARK: - Setup
    
    private func setupView() {
        headerView.backgroundColor = .arBlack.withAlphaComponent(0.7)
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        rewardsButton.isHidden = !ARView.availableExperiences.contains(.rewards)
        huntsButton.isHidden = !ARView.availableExperiences.contains(.hunts)
        rewardsButton.setupCircleButton(experience: .rewards)
        huntsButton.setupCircleButton(experience: .hunts)
        if #available(iOS 13.0, *) {
            backButton.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        } else {
            // Fallback on earlier versions
            backButton.setTitle("<", for: .normal)
        }
        backButton.tintColor = .arWhite
        moveButton.backgroundColor = ARView.branding.primaryColor
        moveButton.clipsToBounds = true
        moveButton.layer.cornerRadius = 5
        moveButton.setTitleColor(.arWhite, for: .normal)
        moveButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        
        messageImage.tintColor = .arBlack
        messageView.backgroundColor = .arWhite
        messageView.layer.cornerRadius = 5
        messageLabel.textColor = .arBlack
        messageLabel.font = ARView.FontStyle.semibold.font(size: 14)
        
        // Pause ARSurface when the app is not on focus and resume once it is again.
        NotificationCenter.default.addObserver(self, selector: #selector(pauseAR), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(resumeAR), name: UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    private func setupPermissions() {
        // Camera
        AVCaptureDevice.requestAccess(for: .video) { isGranted in
            if !isGranted {
                self.showPermissionOverlay(.camera)
            }
        }
        
        // Microphone
        AVAudioSession.sharedInstance().requestRecordPermission { isGranted in
            if !isGranted {
                self.showPermissionOverlay(.microphone)
            }
        }
    }
    
    private func updateStateUI() {
        messageTimer?.invalidate()
        
        DispatchQueue.main.async {
            if self.currentSurfaceState == .activationShowing {
                self.enableRecordButtons()
                self.enableMoveButton()
            } else {
                self.disableRecordButtons()
                self.disableMoveButton()
            }
            
            let stateInformation: [SurfaceState : (String, [String])] = [
                .findingSurface: ("Point your device at a flat surface to place the activation!", ["ar-device-tilt-down-high", "ar-sevice-tilt-up", "ar-device-tilt-down-low"]),
                .placingActivation: ("Tap the screen to place.", ["ar_device-tap-frame-1", "ar_device-tap-frame-2"])
            ]
            
            guard let information = stateInformation[self.currentSurfaceState] else {
                self.messageView.isHidden = true
                return
            }
            
            self.messageView.isHidden = false
            self.messageLabel.text = information.0
            if self.currentStateStep >= information.1.count {
                self.currentStateStep = 0
            }
            self.messageImage.image = UIImage(named: information.1[self.currentStateStep], in: Bundle.arBundle, compatibleWith: nil)
            
            self.messageTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: false) { [weak self] timer in
                guard let self = self else {
                    return
                }
                
                self.currentStateStep += 1
                self.updateStateUI()
            }
        }
    }
    
    // MARK: - IBActions
    
    @IBAction private func onBackButton() {
        navigationController?.dismiss(animated: true)
    }
    
    @IBAction private func onRewardsButton() {
        ARView.showExperience(.rewards, on: navigationController)
    }
    
    @IBAction private func onHuntsButton() {
        ARView.showExperience(.hunts, on: navigationController)
    }
    
    @IBAction private func onCaptureTapButton(_ sender: UITapGestureRecognizer) {
        takeScreenshot()
    }
    
    @IBAction private func onCaptureLongPressButton(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            startRecording()
        } else if sender.state == .ended || sender.state == .cancelled {
            stopRecording()
        }
    }
    
    // MARK: - Methods - IAR Surface Status
    
    private func startAR() {
        
        // ARSurface needs a marker to start, if none was received, it can't start
        guard let marker = self.marker else {
            NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: "No marker given to show."])
            return
        }
        
        // Load and assing a marker
        surfaceView.load()
        surfaceView.marker = marker
        
        // Setup its delegate
        surfaceView.delegate = self
        
        recorderV2?.delegate = self
    }
    
    @objc private func pauseAR() {
        if surfaceView == nil{
            return
        }
        
        surfaceView.stop()
    }
    
    @objc private func resumeAR() {
        if surfaceView == nil {
            return
        }
        
        surfaceView.start()
    }
    
    private func dispose() {
        recorderV2?.stopRecording()
        recorderV2?.dispose()
        recorderV2 = nil
        surfaceView.dispose()
    }
    
    // MARK: - Move
    
    @IBAction private func onMoveButton(_ sender: Any) {
        // Allow the user to move the asset that is currently anchored
        surfaceView.unanchorAsset()
        currentSurfaceState = .placingActivation
    }
    
    private func enableMoveButton() {
        moveButton.isEnabled = true
        moveButton.isHidden = false
    }
    
    private func disableMoveButton() {
        moveButton.isEnabled = false
        moveButton.isHidden = true
    }
    
    
    // MARK: - Screenshot and Recording
    
    private func takeScreenshot() {
        // Returns an UIImage for the Surface view
        let screenshotImage: UIImage = screenshotTaker.takeScreenshot(self.surfaceView)
        
        // With that image, it's possible to present a share modal so the user can save or share wherever they want.
        // NOTE: To share, the user may need to give permission to contacts.
        // NOTE: To save on photos, the user may need to give permission to the photos app.
        let ActivityController = UIActivityViewController(activityItems: [screenshotImage], applicationActivities: nil)
        self.present(ActivityController, animated: true, completion: nil)
    }
    
    private func startRecording() {
        disableRecordButtons()
        
        recorderV2?.startRecording()
        currentRecordingTime = 0
        showCircularProgressView()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.stopRecording()
        }
    }
    
    private func resetRecordingButtons() {
        enableRecordButtons()
    }
    
    private func stopRecording() {
        hideCircularProgressView()
        
        // Calling stop recording returns the video path after it is created
        recorderV2?.stopRecording().onSuccess(callback: { url in
            DispatchQueue.main.async {
                self.resetRecordingButtons()
                
                // With the video URL, it's possible to present a share modal so the user can save or share wherever they want
                // NOTE: To shar, the user may need to give permission to contacts.
                // NOTE: To save on photos, the user may need to give permission to the photos app.
                let ActivityController = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                self.present(ActivityController, animated: true, completion: nil)
            }
        })
    }
    
    private func enableRecordButtons() {
        captureButton.isHidden = false
    }
    
    private func disableRecordButtons() {
        captureButton.isHidden = true
    }
    
    private func showCircularProgressView() {
        disableMoveButton()
        disableRecordButtons()
        
        circularProgressView = ARCircularProgressView(frame: CGRect(x: 0, y: 0, width: 90, height: 90))
        circularProgressView.center = captureButton.center
        circularProgressView.progressAnimation(duration: duration) {
            self.hideCircularProgressView()
        }
        
        view.addSubview(circularProgressView)
    }
    
    private func hideCircularProgressView() {
        circularProgressView.layer.removeAllAnimations()
        enableMoveButton()
        enableRecordButtons()
        circularProgressView.removeFromSuperview()
    }
}

// MARK: - Extension IARSurfaceViewDelegate

extension ARSurfaceScreen: IARSurfaceViewDelegate {
    
    // MARK: - Required delegate methods
    
    // Called when an error occurs
    func surfaceView(_ surfaceView: IARSurfaceView, onError error: Error) {
        NotificationCenter.default.post(
            name: ARView.errorNotificationName,
            object: nil,
            userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription]
        )
    }
    
    // Define is the asset will only be shown on tap
    func surfaceViewOnlyShowAssetOnTap(_ surfaceView: IAR_Surface_SDK.IARSurfaceView) -> Bool {
        return false
    }

    // MARK: - Optional delegate methods
    
    // Called when a surface is detected
    func surfaceViewSurfaceDetected(_ surfaceView: IARSurfaceView) {
        // Don't revert back if a surface is detected again, only on move button
        if currentSurfaceState != .activationShowing {
            currentSurfaceState = .placingActivation
        }
    }

    // Called when an asset is anchored
    func surfaceViewAssetAnchored(_ surfaceView: IARSurfaceView) {
        currentSurfaceState = .activationShowing
        
        // When the asset is anchored, Moving and Recording is available
        enableRecordButtons()
        enableMoveButton()
    }

    // Define if the AR asset can be scaled by user input - default FALSE
    func surfaceViewCanScaleAsset(_ surfaceView: IARSurfaceView) -> Bool {
        return false
    }

    // Called to show the current download progress of any asset
    func surfaceView(_ surfaceView: IARSurfaceView, downloadProgress progress: CGFloat) {}
}

// MARK: - Extension SurfaceRecorderDelegate

extension ARSurfaceScreen: SurfaceRecorderDelegate {
    func onError(error: Error) {
        DispatchQueue.main.async {
            self.resetRecordingButtons()
            NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: "Recording error"])
        }
    }
    
}

