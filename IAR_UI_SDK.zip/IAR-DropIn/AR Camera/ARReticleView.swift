import UIKit

final class ARReticleView: UIView {
    
    static let lineWidth = 10.0
    
    override func draw(_ rect: CGRect) {
        let aPath = UIBezierPath()
        
        let halfLineWidth = ARReticleView.lineWidth * 0.5
        let width = rect.size.width * 0.25
        
        aPath.move(to: CGPoint(x: width, y: halfLineWidth))
        aPath.addLine(to: CGPoint(x: halfLineWidth, y: halfLineWidth))
        aPath.addLine(to: CGPoint(x: halfLineWidth, y: rect.size.height - halfLineWidth))
        aPath.addLine(to: CGPoint(x: width, y: rect.size.height - halfLineWidth))
        
        aPath.move(to: CGPoint(x: rect.size.width - width, y: halfLineWidth))
        aPath.addLine(to: CGPoint(x: rect.size.width - halfLineWidth, y: halfLineWidth))
        aPath.addLine(to: CGPoint(x: rect.size.width - halfLineWidth, y: rect.size.height - halfLineWidth))
        aPath.addLine(to: CGPoint(x: rect.size.width - width, y: rect.size.height - halfLineWidth))

        // If you want to stroke it with a red color
        UIColor.arWhite.set()

        aPath.lineWidth = ARReticleView.lineWidth
        aPath.lineCapStyle = .round
        aPath.stroke()
    }
}
