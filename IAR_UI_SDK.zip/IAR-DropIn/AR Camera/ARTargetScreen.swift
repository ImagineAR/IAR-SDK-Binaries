import UIKit
import IAR_Core_SDK
import IAR_Target_SDK

final class ARTargetScreen: UIViewController {
    
    // MARK: - Outlets
    
    @IBOutlet private weak var arView: IARView!
    @IBOutlet private weak var headerView: UIView!
    @IBOutlet private weak var backButton: UIButton!
    @IBOutlet private weak var headerLabel: UILabel!
    @IBOutlet private weak var rewardsButton: UIButton!
    @IBOutlet private weak var huntsButton: UIButton!
    @IBOutlet private weak var captureButton: UIImageView!
    @IBOutlet private weak var messageView: UIView!
    @IBOutlet private weak var messageIcon: UIImageView!
    @IBOutlet private weak var messageLabel: UILabel!
    @IBOutlet private weak var progressView: UIProgressView!
    @IBOutlet private weak var reticleView: ARReticleView!
    @IBOutlet private weak var overlayMask: UIView!
    
    // MARK: - Properties
    
    private var circularProgressView: ARCircularProgressView!
    private var duration: TimeInterval = 30
    private var arManager: IARManager?
    private var recorder = IARRecorder()
    private var isTracking = false {
        didSet {
            captureButton.isHidden = isTracking
            messageView.isHidden = !isTracking
            reticleView.isHidden = !isTracking
            overlayMask.isHidden = !isTracking
        }
    }
    
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        headerView.backgroundColor = .arBlack.withAlphaComponent(0.7)
        headerLabel.textColor = .arWhite
        headerLabel.font = ARView.FontStyle.semibold.font(size: 22)
        rewardsButton.isHidden = !ARView.availableExperiences.contains(.rewards)
        huntsButton.isHidden = !ARView.availableExperiences.contains(.hunts)
        rewardsButton.setupCircleButton(experience: .rewards)
        huntsButton.setupCircleButton(experience: .hunts)
        if #available(iOS 13.0, *) {
            backButton.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        } else {
            // Fallback on earlier versions
            backButton.setTitle("<", for: .normal)
        }
        backButton.tintColor = .arWhite
        
        if #available(iOS 13.0, *) {
            messageIcon.image = UIImage(systemName: "exclamationmark.circle.fill")
        }
        messageIcon.tintColor = .arBlack
        messageView.backgroundColor = .arWhite
        messageView.layer.cornerRadius = 5
        messageLabel.textColor = .arBlack
        messageLabel.font = ARView.FontStyle.semibold.font(size: 14)
        
        progressView.trackTintColor = ARView.branding.secondaryColor
        progressView.progressTintColor = ARView.branding.primaryColor
        progressView.isHidden = true
        
        reticleView.layer.cornerRadius = 5
        reticleView.clipsToBounds = true
        overlayMask.backgroundColor = .arBlack.withAlphaComponent(0.3)
        
        isTracking = true
        
        // Pause IARManager when the app is not on focus and resume once it is again.
        NotificationCenter.default.addObserver(self, selector: #selector(pauseAR), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(startAR), name: UIApplication.didBecomeActiveNotification, object: nil)
        
        setupPermissions()
        ARTutorialOverlay.show(experience: .target, on: view)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.startAR()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        // Stop IARManager when the view will disappear
        stopAR()
        super.viewWillDisappear(animated)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // Start (or resume) IARManager when the view will appear
        startAR()
        super.viewWillAppear(animated)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        let maskLayer = CAShapeLayer()
        maskLayer.frame = overlayMask.bounds

        let rect = CGRect(
            x: reticleView.frame.minX + ARReticleView.lineWidth,
            y: reticleView.frame.minY + ARReticleView.lineWidth - overlayMask.frame.minY,
            width: reticleView.frame.width - (ARReticleView.lineWidth * 2.0),
            height: reticleView.frame.height - (ARReticleView.lineWidth * 2.0)
        )

        let rectPath = UIBezierPath(rect: rect)
        let path = UIBezierPath(rect: overlayMask.bounds)
        path.append(rectPath)
        maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
        maskLayer.path = path.cgPath
        overlayMask.layer.mask = maskLayer
    }
    
    // MARK: - Setup
    
    private func setupPermissions() {
        // Camera
        AVCaptureDevice.requestAccess(for: .video) { isGranted in
            if !isGranted {
                self.showPermissionOverlay(.camera)
            }
        }
        
        // Microphone
        AVAudioSession.sharedInstance().requestRecordPermission { isGranted in
            if !isGranted {
                self.showPermissionOverlay(.microphone)
            }
        }
    }
    
    // MARK: - IBActions
    
    @IBAction private func onBackButton() {
        navigationController?.dismiss(animated: true)
    }
    
    @IBAction private func onRewardsButton() {
        ARView.showExperience(.rewards, on: navigationController)
    }
    
    @IBAction private func onHuntsButton() {
        ARView.showExperience(.hunts, on: navigationController)
    }
    
    @IBAction private func onCaptureTapButton(_ sender: UITapGestureRecognizer) {
        takeScreenshot()
    }
    
    @IBAction private func onCaptureLongPressButton(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .began {
            startRecording()
        } else if sender.state == .ended || sender.state == .cancelled {
            stopRecording()
        }
    }
    
    // MARK: - IAR Status
    
    @objc private func startAR() {
        guard let manager = arManager else {
            self.arManager = IARManager(delegate: self, using: arView)
            return
        }
        manager.resumeAr()
    }
    
    @objc private func pauseAR() {
        guard let manager = arManager else {
            return
        }
        manager.pauseAr()
    }
    
    private func stopAR() {
        guard let manager = arManager else {
            return
        }
        manager.stopAr()
    }
    
    
    // MARK: - Screenshot and Recording
    
    private func takeScreenshot() {
        // Returns an UIImage for the Surface view
        let screenshotImage: UIImage = recorder.takeScreenshot(self.arView)
        
        // With that image, it's possible to present a share modal so the user can save or share wherever they want.
        // NOTE: To share, the user may need to give permission to contacts.
        // NOTE: To save on photos, the user may need to give permission to the photos app.
        let ActivityController = UIActivityViewController(activityItems: [screenshotImage], applicationActivities: nil)
        self.present(ActivityController, animated: true, completion: nil)
    }
    
    private func startRecording() {
        captureButton.isHidden = true
        showCircularProgressView()
        recorder.startRecordingVideo(using: self.arView)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            self.stopRecording()
        }
    }
    
    private func stopRecording() {
        hideCircularProgressView()
        
        recorder.stopRecordingVideo { progress in
        } completion: { url, error in
            DispatchQueue.main.async {
                self.captureButton.isHidden = false
                
                if let error = error {
                    // Handle the error
                    NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: "Recording error"])
                }
                if let url = url {
                    // With the video URL, it's possible to present a share modal so the user can save or share wherever they want
                    let ActivityController = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                    self.present(ActivityController, animated: true, completion: nil)
                }
                
            }
        }
    }
    
    private func showCircularProgressView() {
        circularProgressView = ARCircularProgressView(frame: CGRect(x: 0, y: 0, width: 90, height: 90))
        circularProgressView.center = captureButton.center
        circularProgressView.progressAnimation(duration: duration) {
            self.hideCircularProgressView()
        }
        
        view.addSubview(circularProgressView)
    }
    
    private func hideCircularProgressView() {
        circularProgressView.layer.removeAllAnimations()
        circularProgressView.removeFromSuperview()
    }
}


// MARK: - Extension IARManagerDelegate

extension ARTargetScreen: IARManagerDelegate {
    
    // MARK: - Required delegate methods
    
    // Called when IAR and Vuforia complete initialization
    func manager(_ manager: IARManager, onInitARDone error: Error?) {
        if let error = error {
            NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
        }
    }
    
    // Called when an error occurs
    func manager(_ manager: IARManager, onError error: Error) {
        NotificationCenter.default.post(name: ARView.errorNotificationName, object: nil, userInfo: [ARView.errorNotificationViewController: self, ARView.errorNotificationMessage: error.localizedDescription])
    }
    
    
    // MARK: - Optional delegate methods
    
    // Called when the marker has a reward to display
    func manager(_ manager: IARManager, markerHasReward marker: Marker) {
        print("IAR - markerHasReward")
    }

    // Called when the reward objects and associated files have been downloaded
    func manager(_ manager: IARManager, didReceive rewards: [Reward]) {
        print("IAR - didReceiveRewards")
    }
    
    // WARNING: THIS METHOD IS DEPRECATED. Use 'didReceiveRewards' instead.
    // Called when the reward object and associated files have been downloaded
    func manager(_ manager: IARManager, didReceive reward: Reward) {
        print("IAR - didReceiveReward")
    }

    // Called to check if the augmentation for the selected target should be rendered
    func manager(_ manager: IARManager, shouldRenderAugmentation targetId: String) -> Bool {
        return true
    }
    
    // Called when when an image target is recognized
    func manager(_ manager: IARManager, didScanTarget marker: Marker) {}

    // Called when the IARView changes its tracking status
    func manager(_ manager: IARManager, onTrackingChanged isTracking: Bool) {
        self.isTracking = isTracking
    }

    // Callback for the progress of an asset that is being downloaded.
    // Use it to show feedback for users
    func manager(_ manager: IARManager, downloadProgress progress: CGFloat) {
        if progress > 0.0 && progress < 1.0 {
            progressView.isHidden = false
            progressView.setProgress(Float(progress), animated: true)
        } else {
            progressView.isHidden = true
        }
    }
}
