import Foundation
import UIKit
import IAR_Core_SDK

public class ARView {
    public static let errorNotificationName = NSNotification.Name(rawValue: "ARView.Error.Notification.Name")
    public static let errorNotificationViewController = "ARView.Error.Notification.ViewController"
    public static let errorNotificationMessage = "ARView.Error.Notification.Message"
    
    public struct Branding {
        public let primaryColor: UIColor
        public let secondaryColor: UIColor
        public let brandIcon: UIImage?
        
        public init(primaryColor: UIColor, secondaryColor: UIColor, brandIcon: UIImage?) {
            self.primaryColor = primaryColor
            self.secondaryColor = secondaryColor
            self.brandIcon = brandIcon
        }
    }
    
    public enum ARExperiences: CaseIterable {
        case homeScreen
        case target
        case surface
        case onDemand
        case location
        case rewards
        case hunts
        public var name: String {
            switch self {
            case .homeScreen: return "Home Screen"
            case .target: return "Scan AR Target"
            case .surface: return "Place an AR Target"
            case .onDemand: return "On Demand Markers"
            case .location: return "AR Near Me"
            case .rewards: return "My Rewards"
            case .hunts: return "AR Hunts"
            }
        }
        var icon: UIImage? {
            return UIImage.imageFor(experience: self)
        }
        var bannerImage: UIImage? {
            var imageName: String?
            switch self {
            case .homeScreen: break
            case .target: imageName = "target-banner-image"
            case .surface: break
            case .onDemand: imageName = "on-demand-banner-image"
            case .location: imageName = "location-banner-image"
            case .rewards: break
            case .hunts: imageName = "hunts-banner-image"
            }
            return imageName == nil ? nil : UIImage(named: imageName!, in: Bundle.arBundle, compatibleWith: nil)
        }
        var tutorialDescription: String? {
            switch self {
            case .homeScreen: return nil
            case .target: return "Use the camera to scan an activated AR target. Keep the camera directed at the target to reveal an AR experience."
            case .surface: return nil
            case .onDemand: return nil
            case .location: return "Use the map to discover AR experiences near you. Once 'Nearby', tap on the experience to open the camera."
            case .rewards: return nil
            case .hunts: return "Browse the list of available AR Hunts and your progress. Participate in the AR experiences to earn rewards."
            }
        }
    }
    
    static public var branding = Branding(
        primaryColor: .brown,
        secondaryColor: .green,
        brandIcon: nil
    )
    static public var availableExperiences: [ARExperiences] = [.homeScreen, .target, .surface, .onDemand, .location, .rewards, .hunts]
    
    
    
    /// Show a prebuilt AR experience
    /// - Parameters:
    ///   - experience: The experience to show
    ///   - marker: Optional marker if one has been downloaded outside the DropIn screens, only Surface requires a marker to be show directly
    ///   - navigationController: The navigation contreoller to be shown on, if none provided it will try to find the top one
    /// - Returns: If an error happens trying to show the experience
    @discardableResult static public func showExperience(_ experience: ARExperiences, marker: Marker? = nil, on navigationController: UINavigationController?) -> String? {
        guard let navigationController = navigationController ?? Utils.topNavigationController() ?? Utils.topViewController()?.navigationController else {
            return "No navigation controller can be found to use"
        }
        
        if !availableExperiences.contains(experience) {
            return "Experience not available"
        }
        
        ARView.loadAllFonts()
        
        var errorMessage: String?
        
        switch experience {
        case .target:
            let arNavController = UINavigationController(rootViewController: ARTargetScreen(nibName: "ARTargetScreen", bundle: Bundle.arBundle))
            arNavController.modalPresentationStyle = .fullScreen
            arNavController.isNavigationBarHidden = true
            navigationController.present(arNavController, animated: true)
        case .surface:
            if marker != nil {
                let surfaceScreen = ARSurfaceScreen(nibName: "ARSurfaceScreen", bundle: Bundle.arBundle)
                surfaceScreen.marker = marker
                let arNavController = UINavigationController(rootViewController: surfaceScreen)
                arNavController.modalPresentationStyle = .fullScreen
                arNavController.isNavigationBarHidden = true
                navigationController.present(arNavController, animated: true)
            } else {
                errorMessage = "Surface AR requires a preloaded marker"
            }
        case .onDemand:
            navigationController.pushViewController(AROnDemandScreen(nibName: "AROnDemandScreen", bundle: Bundle.arBundle), animated: true)
        case .location:
            navigationController.pushViewController(ARLocationScreen(nibName: "ARLocationScreen", bundle: Bundle.arBundle), animated: true)
        case .rewards:
            let arNavController = UINavigationController(rootViewController: ARRewardsScreen(nibName: "ARRewardsScreen", bundle: Bundle.arBundle))
            arNavController.isNavigationBarHidden = true
            navigationController.present(arNavController, animated: true)
        case .hunts:
            let arNavController = UINavigationController(rootViewController: ARHuntsScreen(nibName: "ARHuntsScreen", bundle: Bundle.arBundle))
            arNavController.isNavigationBarHidden = true
            navigationController.present(arNavController, animated: true)
        case .homeScreen:
            navigationController.pushViewController(ARHomeScreen(nibName: "ARHomeScreen", bundle: Bundle.arBundle), animated: true)
        }
        
        return errorMessage
    }
    
    static private var loadedFonts = false
    
    private static func loadAllFonts() {
        guard !ARView.loadedFonts else { return }
        FontStyle.allCases.map {
            loadFont($0.value)
        }
        ARView.loadedFonts = true
    }
    
    private static func loadFont(_ fontName: String) {
        guard
            !ARView.loadedFonts,
            let fontURL = Bundle.arBundle.url(forResource: fontName, withExtension: "ttf"),
            let fontData = try? Data(contentsOf: fontURL) as CFData,
            let provider = CGDataProvider(data: fontData),
            let font = CGFont(provider) else {
            return
        }
        CTFontManagerRegisterGraphicsFont(font, nil)
    }
    
    enum FontStyle: CaseIterable {
        case regular
        case semibold
        case extrabold
        var value: String {
            switch self {
            case .regular: return "Exo-Regular"
            case .semibold: return "Exo-SemiBold"
            case .extrabold: return "Exo-ExtraBold"
            }
        }
        func font(size: CGFloat) -> UIFont {
            return UIFont(name: self.value, size: size) ?? UIFont.init()
        }
      }
}
