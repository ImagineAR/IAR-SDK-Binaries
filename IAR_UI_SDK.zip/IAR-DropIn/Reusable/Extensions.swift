import Foundation
import UIKit
import IAR_Core_SDK
import SnapKit

extension UIColor {
    class var arBlack: UIColor {
        return UIColor(red: 0x00/0xFF, green: 0x00/0xFF, blue: 0x00/0xFF, alpha: 1.0)
    }
    
    class var arWhite: UIColor {
        return UIColor(red: 0xFF/0xFF, green: 0xFF/0xFF, blue: 0xFF/0xFF, alpha: 1.0)
    }
    
    class var arGrey700: UIColor {
        return UIColor(red: 0x24/0xFF, green: 0x24/0xFF, blue: 0x24/0xFF, alpha: 1.0)
    }
    
    class var arGrey500: UIColor {
        return UIColor(red: 0xD9/0xFF, green: 0xD9/0xFF, blue: 0xD9/0xFF, alpha: 1.0)
    }
    
    func image() -> UIImage {
            let size = CGSize(width: 1, height: 1)
            return UIGraphicsImageRenderer(size: size).image { rendererContext in
                self.setFill()
                rendererContext.fill(CGRect(origin: .zero, size: size))
            }
        }
}

extension UIButton {
    func setupCircleButton(experience: ARView.ARExperiences) {
        setImage(UIImage.imageFor(experience: experience), for: .normal)
        setTitle("", for: .normal)
        backgroundColor = .arWhite
        tintColor = .arBlack
        layer.cornerRadius = 24
        layer.borderWidth = 2
        layer.borderColor = UIColor.arBlack.cgColor
    }
}

extension UICollectionView {
    var isARDataLoading: Bool {
        get {
            !(subviews.first {
                $0.isKind(of: UIActivityIndicatorView.self)
            }?.isHidden ?? true)
        }
        set {
            var loadingView = subviews.first {
                $0.isKind(of: UIActivityIndicatorView.self)
            } as? UIActivityIndicatorView
            
            if newValue {
                if loadingView == nil {
                    if #available(iOS 13.0, *) {
                        loadingView = UIActivityIndicatorView(style: .large)
                    } else {
                        loadingView = UIActivityIndicatorView(style: .white)
                    }
                    loadingView?.translatesAutoresizingMaskIntoConstraints = false
                    addSubview(loadingView!)
                    loadingView?.snp.makeConstraints({ make in
                        // TODO: Andrew - This is slightly off center
                        make.center.equalTo(self)
                    })
                }
                loadingView?.isHidden = false
                loadingView?.startAnimating()
            } else {
                loadingView?.isHidden = true
                loadingView?.stopAnimating()
            }
        }
    }
}

extension UITableView {
    var isARDataLoading: Bool {
        get {
            !(subviews.first {
                $0.isKind(of: UIActivityIndicatorView.self)
            }?.isHidden ?? true)
        }
        set {
            var loadingView = subviews.first {
                $0.isKind(of: UIActivityIndicatorView.self)
            } as? UIActivityIndicatorView
            
            if newValue {
                if loadingView == nil {
                    if #available(iOS 13.0, *) {
                        loadingView = UIActivityIndicatorView(style: .large)
                        loadingView?.translatesAutoresizingMaskIntoConstraints = false
                        addSubview(loadingView!)
                        NSLayoutConstraint.activate([
                            loadingView!.centerXAnchor.constraint(equalTo: self.centerXAnchor),
                            loadingView!.centerYAnchor.constraint(equalTo: self.centerYAnchor)
                        ])
                    } else {
                        // Fallback on earlier versions
                    }
                }
                loadingView?.isHidden = false
                loadingView?.startAnimating()
            } else {
                loadingView?.isHidden = true
                loadingView?.stopAnimating()
            }
        }
    }
}

extension UIViewController {
    var isShowingLoadingARView: Bool {
        get {
            !(view.subviews.first {
                $0.isKind(of: ARLoadingOverlay.self)
            }?.isHidden ?? true)
        }
        set {
            var loadingOverlay = view.subviews.first {
                $0.isKind(of: ARLoadingOverlay.self)
            } as? ARLoadingOverlay
            
            if newValue {
                if loadingOverlay == nil {
                    loadingOverlay = ARLoadingOverlay()
                    loadingOverlay?.overlay(on: view)
                }
                loadingOverlay?.isHidden = false
            } else {
                loadingOverlay?.isHidden = true
                loadingOverlay?.removeFromSuperview()
            }
        }
    }
    
    func showRewardDetails(_ reward: Reward) {
        let rewardOverlay = ARRewardOverlay()
        rewardOverlay.load(reward: reward)
        rewardOverlay.overlay(on: view)
    }
    
    func showPermissionOverlay(_ permission: ARPermissionsOverlay.Permissions) {
        DispatchQueue.main.async {
            let permissionsOverlay = ARPermissionsOverlay()
            permissionsOverlay.load(permission: permission)
            permissionsOverlay.overlay(on: self.view)
        }
    }
}

extension UIImageView {
    // TODO: Andrew - issue with this is on any of the collection views it doesn't recycle well since it just sets the image
    func downloaded(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() { [weak self] in
                self?.image = image
            }
        }.resume()
    }
    func downloaded(from link: String, contentMode mode: ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}

extension UIImage {
    static func imageFor(type: IAR_Core_SDK.MarkerType) -> UIImage? {
        switch type {
        case .image:
            if #available(iOS 13.0, *) {
                return UIImage(systemName: "square.dashed")
            }
        case .location:
            return UIImage(named: "location-marker", in: Bundle.arBundle, compatibleWith: nil)
        case .ondemand:
            if #available(iOS 13.0, *) {
                return UIImage(systemName: "eye.fill")
            }
        case .unknown:
            break
        @unknown default:
            break
        }
        
        return nil
    }
    
    static func imageFor(experience: ARView.ARExperiences) -> UIImage? {
        if #available(iOS 13.0, *) {
            switch experience {
            case .surface:
                return nil
            case .onDemand:
                return UIImage(systemName: "eye.fill")
            case .location:
                return UIImage(named: "location-marker", in: Bundle.arBundle, compatibleWith: nil)
            case .target:
                return UIImage(systemName: "square.dashed")
            case .rewards:
                return UIImage(systemName: "gift")
            case .hunts:
                return UIImage(systemName: "map")
            case .homeScreen:
                return UIImage(systemName: "house")
            }
        }
        return nil
    }
}

extension Reward {
    // Stored in the reward object as "ReasonType"
    enum RewardType: String {
        case Unknown = "Unknown"
        case Marker = "Marker"
        case Promotion = "Promotion"
        case Hunt = "Hunt"
        case Web = "Web"
    }
}

extension Bundle {
    static var arBundle: Bundle {
        return Bundle(for: ARView.self)
    }
}
