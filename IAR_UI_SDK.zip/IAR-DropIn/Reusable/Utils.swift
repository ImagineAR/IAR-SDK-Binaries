import Foundation
import UIKit

class Utils {
    class func topViewController(_ viewController: UIViewController? = nil) -> UIViewController? {
        var foundController = viewController
        
        if foundController == nil {
            if #available(iOS 15.0, *) {
                guard let keyController = UIApplication.shared.connectedScenes.compactMap({ ($0 as? UIWindowScene)?.keyWindow }).last?.rootViewController else {
                    return nil
                }
                foundController = keyController
            } else {
                guard let keyController = UIApplication.shared.keyWindow?.rootViewController else {
                    return nil
                }
                foundController = keyController
            }
        }
        
        if let nav = foundController as? UINavigationController {
            return topViewController(nav.visibleViewController)
        }
        if let tab = foundController as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(selected)
            }
        }
        if let presented = foundController?.presentedViewController {
            return topViewController(presented)
        }
        return foundController
    }
        
    class func topNavigationController(_ viewController: UIViewController? = nil) -> UINavigationController? {
        var foundController = viewController
        
        if foundController == nil {
            if #available(iOS 15.0, *) {
                guard let keyController = UIApplication.shared.connectedScenes.compactMap({ ($0 as? UIWindowScene)?.keyWindow }).last?.rootViewController else {
                    return nil
                }
                foundController = keyController
            } else {
                guard let keyController = UIApplication.shared.keyWindow?.rootViewController else {
                    return nil
                }
                foundController = keyController
            }
        }
        
        if let nav = foundController as? UINavigationController {
            return nav
        }
        if let tab = foundController as? UITabBarController {
            if let selected = tab.selectedViewController {
                return selected.navigationController
            }
        }
        return foundController?.navigationController
    }
}
