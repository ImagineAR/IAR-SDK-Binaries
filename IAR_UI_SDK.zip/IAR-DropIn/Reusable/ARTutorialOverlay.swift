import Foundation
import UIKit

final class ARTutorialOverlay: OverlayView {
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var bannerImage: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var goButton: UIButton!

    // MARK: - Setup
    
    override func setupView() {
        super.setupView()
        
        cardView.clipsToBounds = true
        cardView.backgroundColor = .arWhite
        cardView.layer.cornerRadius = 5
        goButton.backgroundColor = ARView.branding.primaryColor
        goButton.setTitleColor(.arWhite, for: .normal)
        goButton.tintColor = .arWhite
        goButton.imageView?.tintColor = .arWhite
        goButton.layer.cornerRadius = 5
        goButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        goButton.semanticContentAttribute = .forceRightToLeft
        if #available(iOS 13.0, *) {
            // Reverse image due to forcing right to left
            goButton.setImage(UIImage(systemName: "arrow.backward"), for: .normal)
        }
        
        titleLabel.textColor = .arBlack
        titleLabel.font = ARView.FontStyle.semibold.font(size: 20)
        descriptionLabel.textColor = .arBlack
        descriptionLabel.font = ARView.FontStyle.regular.font(size: 18)
    }
    
    private func load(experience: ARView.ARExperiences) {
        bannerImage.image = experience.bannerImage
        titleLabel.text = experience.name
        descriptionLabel.text = experience.tutorialDescription
    }
    
    // MARK: - IBActions
    
    @IBAction private func closeTapped() {
        removeFromSuperview()
    }
    
    // MARK: - Static
    
    
    /// Try to show the tutorial of an experience on a view. It self contains and remembers if it has shown that one before so it won't show it again
    /// - Parameters:
    ///   - experience: The experience to use for the information of the tutorial
    ///   - view: The view that the tutorial overlay will be added to
    static func show(experience: ARView.ARExperiences, on view: UIView) {
        let key = "AR Tutorial: \(experience.name)"
        if UserDefaults.standard.bool(forKey: key) {
            return
        }
        
        UserDefaults.standard.setValue(true, forKey: key)
        UserDefaults.standard.synchronize()
        
        let tutorialOverlay = ARTutorialOverlay()
        tutorialOverlay.load(experience: experience)
        tutorialOverlay.overlay(on: view)
    }
}
