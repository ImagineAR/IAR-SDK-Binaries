import Foundation
import UIKit
import SnapKit

class NibView: UIView {
    private var view: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setupView()
    }
    
    func setupView() {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [ .flexibleWidth, .flexibleHeight ]
        addSubview(view)
    }
    
    private func loadViewFromNib() -> UIView {
        return Bundle.arBundle.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?.first as? UIView ?? UIView()
    }
}

class OverlayView: NibView {
    override func setupView() {
        super.setupView()
        
        backgroundColor = .arBlack.withAlphaComponent(0.6)
    }
    
    func overlay(on view: UIView) {
        translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(self)
        snp.makeConstraints { make in
            make.center.equalTo(view)
            make.width.equalTo(view)
            make.height.equalTo(view)
        }
    }
}

class NibCollectionViewCell: UICollectionViewCell {
    private var view: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setupView()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        setupView()
    }
    
    func setupView() {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [ .flexibleWidth, .flexibleHeight ]
        addSubview(view)
    }
    
    private func loadViewFromNib() -> UIView {
        return Bundle.arBundle.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?.first as? UIView ?? UIView()
    }
}

class NibTableViewCell: UITableViewCell {
    private var view: UIView!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupView()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        setupView()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        setupView()
    }
    
    func setupView() {
        view = loadViewFromNib()
        view.frame = bounds
        view.autoresizingMask = [ .flexibleWidth, .flexibleHeight ]
        addSubview(view)
    }
    
    private func loadViewFromNib() -> UIView {
        return Bundle.arBundle.loadNibNamed(String(describing: type(of: self)), owner: self, options: nil)?.first as? UIView ?? UIView()
    }
}
