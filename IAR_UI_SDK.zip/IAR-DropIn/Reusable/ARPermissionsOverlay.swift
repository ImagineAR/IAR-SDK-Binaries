import Foundation
import UIKit

final class ARPermissionsOverlay: OverlayView {
    enum Permissions {
        case location
        case camera
        case microphone
    }
    
    // MARK: - IBOutlets
    
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var iconImage: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var settingsButton: UIButton!
    @IBOutlet private weak var laterButton: UIButton!
    
    private var currentPermission: Permissions!
    
    // MARK: - Setup

    override func setupView() {
        super.setupView()
        
        cardView.backgroundColor = .arWhite
        cardView.layer.cornerRadius = 5
        if #available(iOS 13.0, *) {
            iconImage.image = UIImage(systemName: "exclamationmark.circle.fill")
        }
        iconImage.tintColor = .arBlack
        titleLabel.textColor = .arBlack
        titleLabel.font = ARView.FontStyle.semibold.font(size: 20)
        descriptionLabel.textColor = .arBlack
        descriptionLabel.font = ARView.FontStyle.regular.font(size: 18)
        settingsButton.layer.cornerRadius = 5
        settingsButton.backgroundColor = ARView.branding.primaryColor
        settingsButton.setTitleColor(.arWhite, for: .normal)
        settingsButton.tintColor = .arWhite
        settingsButton.titleLabel?.font = ARView.FontStyle.semibold.font(size: 22)
        settingsButton.semanticContentAttribute = .forceRightToLeft
        if #available(iOS 13.0, *) {
            // Reverse image due to forcing right to left
            settingsButton.setImage(UIImage(systemName: "arrow.backward"), for: .normal)
        }
        laterButton.setAttributedTitle(NSAttributedString(
            string: "Maybe Later",
            attributes: [
                .font: ARView.FontStyle.semibold.font(size: 20),
                .foregroundColor: UIColor.arBlack,
                .underlineStyle: NSUnderlineStyle.single.rawValue,
                .underlineColor: UIColor.arBlack
            ]
        ), for: .normal)
    }
    
    /// Load in the UI for a specific permission
    /// - Parameter permission: The permission that needs to be enabled in settings
    func load(permission: Permissions) {
        currentPermission = permission
        
        switch permission {
        case .location:
            descriptionLabel.text = "AR Near Me requires your location. To continue please allow Location Services in Settings."
        case .camera:
            descriptionLabel.text = "AR experiences requires your access to your camera. To continue please allow camera permission in Settings."
        case .microphone:
            descriptionLabel.text = "AR experiences requires your access to your microphone. To continue please allow microphone permission in Settings."
        }
    }
    
    // MARK: - IBActions
    
    @IBAction private func onLaterButton() {
        removeFromSuperview()
    }
    
    @IBAction private func onSettingsButton() {
        guard let url = URL(string:UIApplication.openSettingsURLString) else { return }
        UIApplication.shared.open(url)
        removeFromSuperview()
    }
}
