import Foundation
import UIKit

public class ARHomeScreen: UIViewController {
    
    // MARK: - IBActions
    
    @IBOutlet private weak var scrollView: UIScrollView!
    @IBOutlet private weak var contentStackView: UIStackView!
    @IBOutlet private weak var locationsCard: ARExperienceCard!
    @IBOutlet private weak var targetCard: ARExperienceCard!
    @IBOutlet private weak var onDemandCard: ARExperienceCard!
    @IBOutlet private weak var rewardsButton: UIButton!
    @IBOutlet private weak var huntsButton: UIButton!
    
    // MARK: - Setup
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .arBlack
        
        locationsCard.isHidden = !ARView.availableExperiences.contains(.location)
        targetCard.isHidden = !ARView.availableExperiences.contains(.target)
        onDemandCard.isHidden = !ARView.availableExperiences.contains(.onDemand)
        rewardsButton.isHidden = !ARView.availableExperiences.contains(.rewards)
        huntsButton.isHidden = !ARView.availableExperiences.contains(.hunts)
        
        locationsCard.load(experience: .location)
        targetCard.load(experience: .target)
        onDemandCard.load(experience: .onDemand)
        
        rewardsButton.setupCircleButton(experience: .rewards)
        huntsButton.setupCircleButton(experience: .hunts)
    }
    
    // MARK: - @IBActions
    
    @IBAction private func onLocationsTapped() {
        ARView.showExperience(.location, on: navigationController)
    }
    
    @IBAction private func onTargetTapped() {
        ARView.showExperience(.target, on: navigationController)
    }
    
    @IBAction private func onOnDemandTapped() {
        ARView.showExperience(.onDemand, on: navigationController)
    }
    
    @IBAction private func onRewardsTapped() {
        ARView.showExperience(.rewards, on: navigationController)
    }
    
    @IBAction private func onHuntsTapped() {
        ARView.showExperience(.hunts, on: navigationController)
    }
}
