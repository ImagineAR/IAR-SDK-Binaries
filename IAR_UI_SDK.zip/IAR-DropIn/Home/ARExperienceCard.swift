import Foundation
import UIKit

final class ARExperienceCard: NibView {
    // MARK: - IBOutlets
    @IBOutlet private weak var headerImage: UIImageView!
    @IBOutlet private weak var iconImage: UIImageView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet var cardTap: UITapGestureRecognizer!
    
    // MARK: - Setup

    override func setupView() {
        super.setupView()
        
        backgroundColor = .arWhite
        iconImage.tintColor = .arBlack
        titleLabel.textColor = .arBlack
        clipsToBounds = true
        layer.cornerRadius = 5
        titleLabel.font = ARView.FontStyle.semibold.font(size: 18)
    }
    
    /// Load in the UI for a specific AR experience
    /// - Parameter experience: The AR experience to show
    func load(experience: ARView.ARExperiences) {
        headerImage.image = experience.bannerImage
        iconImage.image = experience.icon
        titleLabel.text = experience.name.uppercased()
    }
}
